
<div class="siteBody">
	<div class="siteLeft" style="width:100%">
		<div class="siteLeftIn" style="background-color:#ffffff;">
			<h1>ՁԵՐ ՕԳՏԱՀԱՇԻՎԸ ԱՐԳԵԼԱՓԱԿՎԱԾ Է<h1>
				<center>
				<i class="fa-solid fa-triangle-exclamation" style="color:#910000;font-size:64px"></i></center><p>
					<?=@$profile?>
				Հարգելի օգտատեր Ձեր օգտահաշիվը արգելափակվել է ադմինիստրացիայի կողմից, քանի որ մենք անճշտություններ ենք հայտնաբերել Ձեր անձնական տվյալներում։<p>Օգտահաշիվը արգելափակումից հանելու համար, կարող եք դիմել ադմինիստրացիային <a href="index.php?page=messages&box=inbox"><b>ՀԱՂՈՐԴԱԳՐՈՒԹՅՈՒՆՆԵՐ</b></a> բաժնում, սեղմելով «ՆՈՐ ՆԱՄԱԿ» կոճակը։<p>Ադմինիստրացիային ճշգրիտ տվյալներ տրամադրոլուց հետո Ձեր օգտահաշիվը կվերաակտիվանա։
				
</div>
</div>

</div>