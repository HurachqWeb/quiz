<script type="text/javascript">
 function signUpPoUp(){
 	signupPopUp.style.display="inline-block";
 	starter.style.display="none";
 }
</script>
<script type="text/javascript">
 function signUpPoUpClose(){
 	signupPopUp.style.display="none";
 	starter.style.display="block";
 }
</script>
<script type="text/javascript">
	function cehckingUsername(){
		let un = document.getElementById("regUsername").value;
		let length = un.length;
		if(length >= 4){
			const http = new XMLHttpRequest();
			let urlThe = "<?=@$domain?>/func/checkingUsername.php?u="+un;            
    		http.open("GET", urlThe);
    		http.send();
    		http.onload = () => document.getElementById("errorMessageRgUsername").innerHTML=http.responseText;
    
    	}
		else{
			if(length > 0){
				document.getElementById("errorMessageRgUsername").innerHTML='<?=@$text_username_char_warnings?>';
			}
			else{
				document.getElementById("errorMessageRgUsername").innerHTML='';
			}
		}
	}
</script>
<script type="text/javascript">
	function cehckingPhone(){
		let un = document.getElementById("regPhone").value;
		let length = un.length;
		if(length >= 2){
			const http = new XMLHttpRequest();
			var urlThe = "<?=@$domain?>/func/cehckingPhone.php?u="+un;            
    		http.open("GET", urlThe);
    		http.send();
    		http.onload = () => document.getElementById("errorMessageRgPhoneNumber").innerHTML=http.responseText;
    
    	}
		if(length === 0){
			document.getElementById("errorMessageRgPhoneNumber").innerHTML='';
		}
		
	}
</script>
<script type="text/javascript">
	function cehckingPassword(){
		let an = document.getElementById("regPassword").value;
		
 	  
		let alength = an.length;
		let aaa = document.getElementById("errorMessageRg").innerHTML;
		if(aaa == "Ծածկագիրը պետք է լինի լատինատառ"){
			return false;
		}
		if(alength >= 8){
    		document.getElementById("errorMessageRg").innerHTML='';
    	}
		else{
			if(alength > 0){
				document.getElementById("errorMessageRg").innerHTML='<?=@$text_password_char_warnings?>';
			}
			else{
				document.getElementById("errorMessageRg").innerHTML='';
			}
		}

	}
</script>
<script type="text/javascript">
	function cehckingPasswordReplay(){
		let ps = document.getElementById("regPassword").value;
		let psR = document.getElementById("regPasswordR").value;
		let psRlength = psR.length;

		if(psRlength > 3){
			if(ps != psR){
				document.getElementById("errorMessageRg").innerHTML='<?=@$TextErrorPasswordWarning?>';
			}
			else {
				document.getElementById("errorMessageRg").innerHTML='';
			}
		}
		else{
			document.getElementById("errorMessage").innerHTML='';
		}
		
	}
</script>

<script type="text/javascript">
	function backSignUp(){
		document.getElementById("signupPopUp").style.display="block";
		document.getElementById("signupPopUp2").style.display="none";
	}
</script>
<script type="text/javascript">
	function signUpPoUpNext(){
		let postF_1 = document.getElementById("name").value;
		let postF_2 = document.getElementById("lastname").value;
		let postF_3 = document.getElementById("regUsername").value;
		let postF_5 = document.getElementById("regPassword").value;
		let postF_6 = document.getElementById("regPasswordR").value;
		let postF_7 = document.getElementById("regPhone").value;
		let phnLenght = postF_7.length;
		let postF_8 = document.getElementById("errorMessageRg").innerHTML;
		let postF_12 = document.getElementById("errorMessageRgUsername").innerHTML;
		let postF_13 = document.getElementById("errorMessageRgPhoneNumber").innerHTML;
		let postF_14 = document.getElementById("errorMessageRgPhoneNumber2").innerHTML;

		let postF_9 = document.getElementById("birth_day").value;
		let postF_10 = document.getElementById("birth_mounth").value;
		let postF_11 = document.getElementById("birth_year").value;
		if(postF_9 == null || postF_9 == "")
		{
			document.getElementById("errorMessageRg").innerHTML='<?=@$textNeedMarkAllFields?>';
				return false;
		}
		else{
				document.getElementById("errorMessageRg").innerHTML='';
		}
		if(postF_10 == null || postF_10 == "")
		{
			document.getElementById("errorMessageRg").innerHTML='<?=@$textNeedMarkAllFields?>';
				return false;
		}
		else{
				document.getElementById("errorMessageRg").innerHTML='';
		}
		if(postF_11 == null || postF_11 == "")
		{
			document.getElementById("errorMessageRg").innerHTML='<?=@$textNeedMarkAllFields?>';
				return false;
		}
		else{
			document.getElementById("errorMessageRg").innerHTML='';
		}
			let postF_4 = postF_11+"-"+postF_10+"-"+postF_9;
	
		if(postF_12 == null || postF_12 == "")
		{
		}
		else {
			return false;
		}
		if(postF_13 == null || postF_13 == "")
		{
		}
		else {
			return false;
		}
		
		if(postF_8 == null || postF_8 == "")
		{
			if(postF_1 == null || postF_1 == "")
			{
				document.getElementById("errorMessageRg").innerHTML='<?=@$textNeedMarkAllFields?>';
				return false;
			}
			else{
				document.getElementById("errorMessageRg").innerHTML='';
			}
			if(postF_2 == null || postF_2 == "")
			{
				document.getElementById("errorMessageRg").innerHTML='<?=@$textNeedMarkAllFields?>';
				return false;
			}
			else{
				document.getElementById("errorMessageRg").innerHTML='';
			}
			if(postF_3 == null || postF_3 == "")
			{
				document.getElementById("errorMessageRg").innerHTML='<?=@$textNeedMarkAllFields?>';
				return false;
			}
			else{
				document.getElementById("errorMessageRg").innerHTML='';
			}
			
			if(postF_5 == null || postF_5 == "")
			{
				document.getElementById("errorMessageRg").innerHTML='<?=@$textNeedMarkAllFields?>';
				return false;
			}
			else{
				document.getElementById("errorMessageRg").innerHTML='';
			}
			if(postF_6 == null || postF_6 == "")
			{
				document.getElementById("errorMessageRg").innerHTML='<?=@$textNeedMarkAllFields?>';
				return false;
			}
			else{
				document.getElementById("errorMessageRg").innerHTML='';
			}
			if(postF_7 == null || postF_7 == "")
			{
				document.getElementById("errorMessageRg").innerHTML='<?=@$textNeedMarkAllFields?>';
				return false;
			}
			else{
				document.getElementById("errorMessageRg").innerHTML='';
			}
		}
		else
		{
			return false;
		}
		if(phnLenght < 8){
			document.getElementById("errorMessageRgPhoneNumber2").innerHTML='Հեռախոսահամարը պետք է պարունակի 8 նիշ';
			return false;
		}
		else
		{
			document.getElementById("errorMessageRgPhoneNumber2").innerHTML='';
		}
		if(postF_14 == null || postF_14 == "")
		{
		}
		else {
			return false;
		}
		document.getElementById("regform").submit();
		/*const http = new XMLHttpRequest();
			var urlThe = "<?=@$domain?>/func/signupNext.php?name="+postF_1+"&lastname="+postF_2+"&username="+postF_3+"&birthDay="+postF_4+"&password="+postF_5+"&phoneNumber="+postF_7;            
    		http.open("GET", urlThe);
    		http.send();
    		http.onload = () => document.getElementById("regiLine2").innerHTML=http.responseText;*/
	}
</script>
<script type="text/javascript">
	function regActivation(){
		let var1 = document.getElementById("s2_activatioCode").value;
		let var2 = document.getElementById("s2_name").value;
		let var3 = document.getElementById("s2_lastname").value;
		let var4 = document.getElementById("s2_username").value;
		let var5 = document.getElementById("s2_password").value;
		let var6 = document.getElementById("s2_birthDay").value;
		let var7 = document.getElementById("s2_phoneNumber").value;
		let var8 = document.getElementById("actIvateSMS").value;
		let var9 = document.getElementById("rule1").checked;
		let var10 = document.getElementById("rule2").checked;
		if(var1 != var8)
		{
			document.getElementById("errorMessageStep2").innerHTML='<?=@$TextErorrActivationCode?>';
			return false;
		}
		else{
			document.getElementById("errorMessageStep2").innerHTML='';
		}
		if(var9 === false)
		{
			document.getElementById("errorMessageStep2").innerHTML='<?=@$pleaseAcceptRule?>';
			return false;
		}
		else{
			document.getElementById("errorMessageStep2").innerHTML='';
		}
		if(var10 === false)
		{
			document.getElementById("errorMessageStep2").innerHTML='<?=@$pleaseAcceptRule?>';
			return false;
		}
		else{
			document.getElementById("errorMessageStep2").innerHTML='';
		}
		document.getElementById("regFinForm").submit();
		/*const http = new XMLHttpRequest();
			var urlThe = "<?=@$domain?>/func/signupFinish.php?activatonCode="+var1+"&name="+var2+"&lastname="+var3+"&username="+var4+"&birthDay="+var6+"&password="+var5+"&phoneNumber="+var7;            
    		http.open("GET", urlThe);
    		http.send();
    		http.onload = () => document.getElementById("regiLine").innerHTML=http.responseText;*/
	}
</script>
<script type="text/javascript">
	function signIn(){
		let un = document.getElementById("username").value;
		let ps = document.getElementById("password").value;
		let rm = document.getElementById("rm").checked;

		if(un == null || un == "" || ps == null || ps == "")
		{
			document.getElementById("errorMessage").innerHTML = '<?=@$TextSignInDetilesIsMissing?>';
			return false;
		}
		else {
			document.getElementById("errorMessage").innerHTML = '';
		}
			document.getElementById("loginForm").submit();
	}
</script>
<script type="text/javascript">
	function signOut() {
		const http = new XMLHttpRequest();
		var urlThe = "<?=@$domain?>/func/signOut.php";            
    	http.open("GET", urlThe);
    	http.send();
    	http.onload = () => document.getElementById("signOBar").innerHTML=http.responseText;
	}
</script>
<script type="text/javascript">
	function startQuiz(id){
		document.getElementById("selected_quiz").value=id;
		document.getElementById("quiz_terms_popup").style.display="block";
		document.getElementById("taskRuls").src="<?=$domain?>/inc/task-rules.php?id="+id;
	}
</script>
<script type="text/javascript">
	function getVisa(val){
		document.getElementById("visaAnswer").value = val
		if(val == "yes"){
			document.getElementById("novisa").checked = false;
		}else{
			document.getElementById("visa").checked = false;
		}
	}
	function startQuizStepTwo() {
		let quiz = document.getElementById("selected_quiz").value;
		let visa_1 = document.getElementById("visaAnswer").value;
		startbtn.style.display="none";
		const http = new XMLHttpRequest();
		var urlThe = "<?=@$domain?>/func/startQuiz.php?id="+quiz+"&visa="+visa_1;            
    	http.open("GET", urlThe);
    	http.send();
    	http.onload = () => document.getElementById("quizStart").innerHTML=http.responseText;
	}
</script>
<script type="text/javascript">
	function chekIng(){
		let a = document.getElementById("rule1").checked;
		let b = document.getElementById("rule2").checked;
		if(a === true && b === true){
			document.getElementById("regButton").removeAttribute("disabled");
		}
		if(a === false)
		{
			document.getElementById("regButton").disabled = true;
			return false;
		}
		if(b === false)
		{
			document.getElementById("regButton").disabled = true;
			return false;
		}
	}

</script><script type="text/javascript">
	function chekIngTask(){
		let a = document.getElementById("ruleT").checked;
		if(a === false){

		}
		else
		{
			document.getElementById("startQuizbtn").removeAttribute("disabled");
		}
	}
</script>
<script>
const as = setInterval(report,1000);
function report() {
    var frame_top = $('#taskRuls').contents().find('body').scrollTop();
    if(frame_top >= 100)
    {
    	document.getElementById("ruleT").removeAttribute("disabled");
    }
}
</script>
<script>
const as2 = setInterval(report2,1000);
function report2() {
    var frame_top = $('#siteRuls').contents().find('body').scrollTop();
 
    if(frame_top >= 400)
    {
    	document.getElementById("rule1").removeAttribute("disabled");
    	document.getElementById("rule2").removeAttribute("disabled");
    }

}
</script>
<script type="text/javascript">
	function closeQuizQuestPopUp(){
		document.getElementById("quiz_terms_popup").style.display="none";
	}
</script>

<script type="text/javascript">
	function checkPassOfPreg(event) {
  	let value= event.which;
  	 if (value >= 30 && value <= 122){
  	 	document.getElementById("errorMessageRg").innerHTML='';
  	 }
  	 else{
  	 	document.getElementById("errorMessageRg").innerHTML = "Ծածկագիրը պետք է լինի լատինատառ";
  	 }
  }
</script>
<script type="text/javascript">
	function checkPhoneSignUp(event){
		let varr = event.which;
		if(varr >= 48 && varr<=57){
			document.getElementById("errorMessageRgPhoneNumber").innerHTML='';
		}else{
			document.getElementById("errorMessageRgPhoneNumber").innerHTML='<?=@$phone_number_varn?>';
		}
	}
</script>
<script type="text/javascript">
	function checkPhone(event){
		let varr = event.which;
		if(varr >= 48 && varr<=57){
			document.getElementById("profError").innerHTML='';
		}else{
			document.getElementById("profError").innerHTML='<?=@$phone_number_varn?>';
		}
	}
</script>
<script type="text/javascript">
	function saveProfile(){
		let check = document.getElementById("profError").innerHTML;

		if(check == null || check == "")
		{
			return true;
		}else{
			return false;
		}
	}
</script>
<script type="text/javascript">
	function checkPasswordProfile(){
		let pss = document.getElementById("old_password").value;
		if(pss.length >= 8){
			const http = new XMLHttpRequest();
			var urlThe = "<?=@$domain?>/func/checkPassword.php?pass="+pss;            
    		http.open("GET", urlThe);
    		http.send();
    		http.onload = () => document.getElementById("pssError").innerHTML=http.responseText;
		}
	}
</script>
<script type="text/javascript">
	function checkNewPass(){
		let ps2 = document.getElementById("new_password").value;
		if(ps2.length < 8){
			document.getElementById("pssError2").innerHTML='<?=@$text_password_char_warnings?>';
		}
		else
		{
			document.getElementById("pssError2").innerHTML='';
		}
	}
</script>

<script type="text/javascript">
	function checkPassOfPreg2(event) {
  	let value= event.which;
  	 if (value >= 30 && value <= 122){
  	 	document.getElementById("pssError2").innerHTML='';
  	 }
  	 else{
  	 	document.getElementById("pssError2").innerHTML = "Ծածկագիրը պետք է լինի լատինատառ";
  	 }
  }
</script>
<script type="text/javascript">
	function checkReptPass(){
		let p1 = document.getElementById("new_password").value;
		let p2 = document.getElementById("repeat_password").value;
		if(p1 != p2){
			document.getElementById("pssError3").innerHTML='<?=@$TextErrorPasswordWarning?>';
		}
		else {
			document.getElementById("pssError3").innerHTML='';
		}
	}
</script>
<script type="text/javascript">
	function changePassword() {
		let pst1 = document.getElementById("old_password").value;
		let pst2 = document.getElementById("new_password").value;
		let pst3 = document.getElementById("repeat_password").value;
		let err1 = document.getElementById("pssError").innerHTML;
		let err2 = document.getElementById("pssError2").innerHTML;
		let err3 = document.getElementById("pssError3").innerHTML;
		if(err1 == null || err1 == ""){
		
		}else{
			return false;
		}
		if(err2 == null || err2 == ""){
	
		}else{
			return false;
		}
		if(err3 == null || err3 == ""){
		
		}else{
			return false;
		}
		if(pst1 == null || pst1 == ""){
			return false;
		}else{
		
		}
		if(pst2 == null || pst2 == ""){
			return false;
		}else{
		
		}
		if(pst2 == null || pst2 == ""){
			return false;
		}else{
	
		}
		document.getElementById("old_password").value='';
		document.getElementById("new_password").value='';
		document.getElementById("repeat_password").value='';
			const http = new XMLHttpRequest();
			var urlThe = "<?=@$domain?>/func/changePassword.php?pass="+pst2;            
    		http.open("GET", urlThe);
    		http.send();
    		http.onload = () => document.getElementById("passwordFinish").innerHTML=http.responseText;
	}
</script>
<script type="text/javascript">
	function messageSend(){
		var tit = document.getElementById("title").value;
		var txt = document.getElementById("message_text").value;
		var file = document.getElementById("file").files[0];
		if(tit == null || tit == "" || tit == " "){
			return false;
		}if(txt == null || txt == ""){
			return false;
		}
		
		document.getElementById("mesForm").submit();
	}
</script>