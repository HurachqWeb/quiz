<div id="quiz_terms_popup" class="quiz_terms_popup">
	<div class="quiz_popup_in">
		<p style="text-align:right"><i class="fa fa-close" onclick="closeQuizQuestPopUp()"></i></p>
 <center>
	<iframe id="taskRuls" src="" style="border:none;" ></iframe>
	<p>
		<input type="hidden" id="visaAnswer" value="no">
		<input type="checkbox" id="ruleT" name="rule" onchange="chekIngTask()" value="acceptRule" disabled> <?=@$IAcceptedRuleText?>
		<p>
			<?=@$question_visa?><br>
			<input type="radio" id="visa" onclick="getVisa(this.value)" name="visa" value="yes"> <?=@$text_yes?>
			<input type="radio" id="novisa" onclick="getVisa(this.value)"  name="novisa" value="no" checked/> <?=@$text_no?>
		<p>
		<button id="startQuizbtn" class="regButton" onclick="startQuizStepTwo()" disabled>ՄԱՍՆԱԿՑԵԼ</button>
	</center>
</div>
</div>

<div class="siteBody">
	<div class="siteLeft">
		<input type="hidden" id="selected_quiz" value="">
		<div id="quizStart">
			
		</div>
		<?php
		@$status_text = array('nopublish'=>"Չհրապարակված",'active'=>"Ակտիվ",'pasive'=>"Պասիվ",'finished'=>"ավարտված");
		 function datPrint($dat){
		 	@$months = array('01'=>"հնվ․",'02'=>"փետ․",'03'=>"մարտ",'04'=>"ապր․",'05'=>"մայ․",'06'=>"հնս․",'07'=>"հլս․",'08'=>"օգս․",'09'=>"սեպ․",'10'=>"հոկ․",'11'=>"նոյ․",'12'=>"դեկ․");
		 	@$datchek = explode(' ', $dat);
		 	@$date = @$datchek[0];
		 	@$time = @$datchek[1];
		 	@$print_time = $time[0].$time[1].$time[2].$time[3].$time[4];

		 	@$print_date = explode('-',@$date);

		 	@$result= @$print_date[2]." ".@$months[@$print_date[1]]." ".@$print_date[0]." | ".@$print_time;
		 	return $result;
		 }

			@$qr="select * from quizes where status='pasive' or status='active'  or status='finished' order by status asc, id asc";
			@$rs=mysqli_query($db,$qr);
			@$kl=mysqli_num_rows($rs);
			 @$color_style= array('active'=>"#FFFFFF",'finished'=>"#FFFFFF",'pasive'=>"#d4dede");
			for(@$i=1; @$i<=@$kl;@$i++){
				@$rw=mysqli_fetch_array($rs);
				@$chek_qr = "select * from quizes_answers where quiz_id='".@$rw['id']."' and user_id='".@$profile."'";
				@$check_rs = mysqli_query($db, $chek_qr);
				@$check_kl = mysqli_num_rows($check_rs);
				if(@$check_kl > 0){
					@$check_rw = mysqli_fetch_array($check_rs);
				}


		?>
			<div class="siteLeftIn" style="background-color: <?=@$color_style[@$rw['status']]?>;">
				<div class="quizTitle"><?=@$rw['title_am']?>
					
					<?php 
						@$qr_global_check = "select id from quizes where id='".@$rw['id']."' and start_date <= '".date('Y-m-d H:i:s',$time)."'"; 
						@$rs_global_check = mysqli_query($db,$qr_global_check);
						@$kl_global_check = mysqli_num_rows($rs_global_check);
 						if(@$kl_global_check == 0){
 							echo "<span style=\"float:right;color:orange\">Չմեկնարված</span>";
 						}
 						else
 						{
						if(@$check_kl == 0 && @$rw['status'] == "active"){
							@$qr_check_activation_date = "select id from quizes where end_date >= '".date('Y-m-d H:i:s',$time)."' and id='".@$rw['id']."'";
							
							@$rs_check_activation_date = mysqli_query(@$db,@$qr_check_activation_date);
							@$kl_check_activation_date = mysqli_num_rows(@$rs_check_activation_date);
							if(@$kl_check_activation_date == 1)
							{echo "<button id=\"startbtn\" onclick=\"startQuiz('".@$rw['id']."')\">ՄԱՍՆԱԿՑԵԼ</button>";}
						else{
							echo "<span style=\"float:right;color:#910000\">".@$finished."</span><p><button onclick=\"location.href='".@$domain."index.php?page=quiz&id=".@$rw['id']."'\">ԴԻՏԵԼ</button>";
						}
						}
						if(@$check_kl > 0 && @$rw['status'] == "active"){
							if(@$check_rw['last_ansfered_task'] == 10)
							{
								echo "<button onclick=\"location.href='".@$domain."index.php?page=quiz&id=".@$rw['id']."'\">ԴԻՏԵԼ</button>";
							}
							else
							{if(@$check_rw['last_ansfered_task'] < 10 or @$check_rw['start_sec'] < 600){
														//	echo "<button onclick=\"location.href='".@$domain."index.php?page=quiz&id=".@$rw['id']."'\">ՇԱՐՈՒՆԱԿԵԼ</button>";
														}}
						}
						if(@$check_kl > 0 && @$rw['status'] == "finished"){
							if(@$check_rw['last_ansfered_task'] == 10)
							{
								echo "<button onclick=\"location.href='".@$domain."index.php?page=quiz&id=".@$rw['id']."'\">ԴԻՏԵԼ</button>";
							}
						}
						}
					?>
				</div>
				<div class="task_detiles">
					<span><i class="fa fa-clock"></i>
 <b><?=datPrint(@$rw['start_date'])?></b></span>
					<span><i class="fa fa-flag-checkered" aria-hidden="true"></i>
 <b><?=datPrint(@$rw['end_date'])?></b></span>
					<span><?=@$status_text[@$rw['status']];?></span>
					<span><?php 
					if(@$check_kl > 0 && @$rw['status'] == "active"){
						 echo "<div style=\"line-height:20px\"><font style=\"color:green\">".@$check_rw['points']."/10</font><br>".timerStop(@$check_rw['start_sec']).":".@$check_rw['mil_secs']."</div>";
					}
					?></span>
				</div>
			</div>
		<?php 
			}
		

		?>
	</div>
	<div class="siteRight"></div>
</div>

<div id="demo">&nbsp;</div>