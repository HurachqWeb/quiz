<?php
if(@$_SERVER['HTTP_HOST'] == "localhost" or  @$_SERVER['HTTP_HOST']=="37.252.68.164")
{
  $DB_HOST="localhost";
  $DB_USER="root";
  $DB_PASS="";
  $DB_NAME="quiz";
  @$domain = "http://".@$_SERVER['HTTP_HOST']."/quiz/";
}
else
{ 
  $DB_HOST="localhost";
  $DB_USER="vicjjtnm__rmquiz";
  $DB_PASS='!KsO3$miLMn=';
  $DB_NAME="vicjjtnm_rmquiz";
  @$domain = "https://".@$_SERVER['HTTP_HOST']."/";
}

@$mailAdmin = "no-replay@".@$_SERVER['HTTP_HOST'];

@$db=mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
@$hour=date('H');
@$minutes=date('i');
@$secconds=date('s');
@$day=date('d');
@$month=date('m');
@$year=date('Y');
$time=mktime($hour +4,$minutes,$secconds,$month,$day,$year);
$time_one_month_ago=mktime($hour +4,$minutes,$secconds,$month-1,$day,$year);
$now_time=date('H:i:s', $time);
$now_month=date('d.m.Y', $time);


@$art_status_list = array('in-write' => 'Still writing','completed' => 'Completed');

@$text_yes="այո";
@$text_no="ոչ";
@$question_visa="Ունե՞ք Իսպանիայի մուտքի վիզա";
@$text_login_bar_title = "ՀԱՂԹԻՐ ՍԻՐԵԼԻ ԹԻՄԻԴ ԽԱՂԻՆ ՆԵՐԿԱ ԳՏՆՎԵԼՈՒ ՀՆԱՐԱՎՈՐՈՒԹՅՈՒՆ";
@$text_login_text = "ՄՈՒՏՔ";
@$text_username = "Մուտքագրեք մուտքանունը";
@$text_password_now = "Նշեք Գաղտնաբառը";
@$text_signin_now = "Մուտք";
@$text_signup_now = "Գրանցում";
@$text_name = "Անուն";
@$text_lastname = "Ազգանուն";
@$text_password_replay = "Կրկնել Գաղտնաբառը";
@$passwords_rule="Գաղտնաբառը պետք է լինի ոչ պակաս քան՝ 8 նիշը և ոչ ավելին քան՝ 16 նիշը";
@$text_birthday="Ծնդյան տարեթիվը՝ ԱՄ/ՕՐ/ՏԱՐԻ";
@$username_rule="Մուտքանունը չպետք է լինի՝ 4 նիշից պակաս";
@$phone_rule="Հեռախոսահամարը պետք է լինի հետևյալ ձևաչափով՝ +37499123456";
@$text_username_char_warnings="Մուտքանունը պետք է լինի ոչ պակաս քան 4 նիշը";
@$text_password_char_warnings="Գաղտնաբառը պետք է լինի ոչ պակաս քան 8 նիշը";
@$text_mark_you_phone="Նշեք Ձեր հեռախոսահամարը";
@$text_exist_this_userneme = "Նշված մուտքանունով oգտատեր արդեն գրանցված է";
@$text_exist_this_phone_number = "Նշված հեռախոսահամարով oգտատեր արդեն գրանցված է";
@$TextErrorPasswordWarning="Ձեր կողմից լրացված գաղտնաբառերը չեն համապատասխանում իրար";
@$textNeedMarkAllFields="Անհարժեշտ է լրացնել բոլոր դաշտերը";
@$TextAcceptRegSms="Դուք Ձեր հեռախոսահամարին ստացել եք վեցանիշ ակտիվացման կոդ։<br>Խնդրում ենք այն լրացնել համապատասխան դաշտում և հաստատել Ձեր գրանցումը։";
@$textAccept="ՀԱՍՏԱՏԵԼ";
@$textsixcode="Լրացրեք վեցնիշ կոդը";
@$IAcceptedRuleText="Ես ծանոթացել եմ կանոնների հետ և սույնով հայտնում եմ իմ համաձայնությունը դրանց։";
@$IAcceptedRuleText2="Համաձայն եմ կոնտակտներիս տրամադրմանը գործընկերներին բուքմեյքերական և/կամ գովազդային արշավների առաջարկներ կատարելու նպատակով։";
@$IAcceptedRuleText3="Համաձայն եմ կոնտակտներիս տրամադրմանը գործընկերներին  գովազդային արշավների առաջարկներ կատարելու նպատակով։";
@$TextErorrActivationCode="Ակտիվացիոն կոդը սխալ եք նշել";
@$pleaseAcceptRule = "Չեք նշել ձեր համաձայնությունը կանոններին";
@$thankYouForRegistration = "Շնորհակալություն գրանցման համար։";
@$TextRemeberMe="Հիշել մուտքը";
@$TextSignInDetilesIsWrong="Մուտքանունը կամ գաղտնաբառը սխալ է";
@$TextSignInDetilesIsMissing="Մուտքագրեք մուտքանունը և գաղտնաբառը";
@$TextLogOut="Դուրս գալ";
@$myProfile="ԻՄ ՊՐՈՖԱՅԼԸ";
@$finished = "Ժամանակը ավարտված է";
?>