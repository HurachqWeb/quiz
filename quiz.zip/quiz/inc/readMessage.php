<style>
	.messageDivM {
	    cursor: pointer;
	    padding:10px;
	    width:96%;
	    height: auto;
	    line-height: 25px;
	    margin-bottom: 10px;
	    border-radius:5px;
	    border: 1px solid #00000029;
	}
	.messageDateM{
	    font-size: 12px;
	    font-weight: 700;
	    color: #00529f;
	}
</style>
<form id="mesFormRep" onsubmit="return messageReply()" action="inc/replyMessage.php"  method="post" enctype="multipart/form-data">
	<input type="hidden" name="id" value="<?=@$_GET['id']?>">
<?php
@session_start();

include "../config.php";
@$profile = @$_SESSION['user_id'];
if(!@$profile)
{
	@$profile = @$_COOKIE['user_id'];
}

	@$qr = "select * from messages where id='".@$_GET['id']."'";
	@$rs = mysqli_query($db,$qr);
	@$rw = mysqli_fetch_array($rs);

	@$qr_up = "update messages set status='old' where id='".@$_GET['id']."'";
	mysqli_query($db,$qr_up);
	@$dat = @$rw['added'];
		  				echo "<div class=\"messageDivM\"><span class=\"messageDateM\">".dataPrint($dat)."</span> | <span class=\"messageTitle\">"
		  				.@$rw['title']."</span></div>";

		  				@$qr_attach = "select attach_url from attached_file where added='".@$rw['added']."'";
						@$rs_attach = mysqli_query($db,$qr_attach);
						@$kl_attach = mysqli_num_rows($rs_attach);
						@$rw_attach = mysqli_fetch_array($rs_attach);
						if(@$rw_attach['attach_url'])
						{
							echo "<p> <a href=\"".@$domain."uploads/attached_files/".@$rw_attach['attach_url']."\" target=\"_blank\">Դիտել կցված ֆայլը</a>";
						}
		  				echo"

		  				<div class=\"messageDivM\">".@$rw['message']."</div>
		  				<div class=\"messageDivM\">
		  					<center><textarea id=\"textmessage\" name=\"textR\" class=\"loginInputs\" style=\"width:80%;height:100px\"></textarea><p>
		  					<p>Կցել ֆայլ <input type=\"file\" id=\"fileR\" name=\"fileR\">
		  					<button id=\"startQuizbtn\" class=\"regButton\" onclick=\"messageReply()\">ՊԱՏԱՍԽԱՆԵԼ</button></center>
		  				</div>
		  				";

?>
</form>