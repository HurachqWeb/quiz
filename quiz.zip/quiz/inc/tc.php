
<div id="signupPopUp" class="signupPopUp"  style="display:block;">
	<div class="loginBarTitle"><?=@$text_signup_now?></div>
		<div id="regiLine" class="regiLine">
	
		<center><p>Դրությներ և Պայմաններ</p>
	<p>
		<iframe id="siteRuls" src="<?=@$doamin?>/inc/site-rules.php" style="border:none;"></iframe>
		
		</center>
</div>
</div>
