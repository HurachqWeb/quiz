<style>

@import url('https://fonts.googleapis.com/css2?family=Open+Sans&family=Roboto:wght@100;400&display=swap');
body{
    margin:0px;
    margin-bottom: 25px;
    font-size: 18px;
    font-family: 'Open Sans', sans-serif;
    background-image: url('images/bgnew.jpg');
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
    background-position: center center;
    background-color: #000000;
}
a{
    color: #00529f;
    font-weight: 900px;
}a:hover {
    color:#000000;
    text-decoration: none;
}
.noBoxLink{
    background-color: #00529f;
    border:1px solid #00529f;
    font-size: 14px;
    padding: 10px;
    color: #ffffff;
    border-radius: 10px;
}
.BoxLink{
    cursor: pointer;
    border:1px solid #00529f;
    font-size: 14px;
    padding: 10px;
    color: #00529f;
    border-radius: 10px;
}
.BoxLink:hover{
    background-color: #ff7300;
    border:1px solid #ff7300;
    color:#fff;
}
.messageDiv {
    cursor: pointer;
    padding:10px;
    width:auto;
    height: auto;
    line-height: 25px;
    margin-bottom: 10px;
    border-radius:5px;
    border: 1px solid #00000029;
}.messageDiv:hover {
    background-color: #00000029;
}
.messageDate{
    font-size: 12px;
    font-weight: 700;
    color: #00529f;
}
#profError{
    color:#910000;
    font-size: 11px;
}
#pssError, #pssError2, #pssError3{
    color:#910000;
    font-size: 11px;
}
#passwordFinish {
    text-align: center;
    font-size: 14px;
    color:#17b338;
}
.inputfile {
  /* visibility: hidden etc. wont work */
  width: 0.1px;
  height: 0.1px;
  opacity: 0;
  overflow: hidden;
  position: absolute;
  z-index: -1;
}
.inputfile:focus + label {
  /* keyboard navigation */
  outline: 1px dotted #000;
  outline: -webkit-focus-ring-color auto 5px;
}
.inputfile + label * {
  pointer-events: none;
}
checkbox {
    width:24px;
    height:24px;
}
button:disabled,
button[disabled]{
  opacity: 0.6;
  cursor: not-allowed;
}
h1 {
    background-color: #ffffff;
    font-size:16px;
    text-align: center;
    font-weight: 400;
    padding: 10px 0px;
    border-radius:6px;
    margin-bottom: 15px;
}
.quiz_popup_in{
    margin:10px;
    width:auto;
    overflow: auto;
}
.liderboard_header {
    width:auto;
    overflow: auto;
    background-color: #00529f;
    padding: 10px 0px;
    color:#ffffff;
    border-radius:6px;
    margin-bottom: 2px;
}
.liderboard_header #position, #points {
    float:left;
    text-align:center;
    width:20%;
}
.liderboard_header #time {
    float:left;
    text-align:center;
    width:30%;
}.liderboard_header #username {
    float:left;
    text-align:left;
    width:30%;
}
.liderboard_li {
    width:auto;
    overflow: auto;
    font-size: 11px;
    background-color: #ffffff;
    padding: 10px 0px;
    color:#000000;
    border-radius:6px;
    margin-bottom: 2px;
}
.liderboard_li #position, #points {
    float:left;
    text-align:center;
    width:20%;
}
.liderboard_li #time {
    float:left;
    text-align:center;
    width:30%;
}.liderboard_li #username {
    float:left;
    text-align:left;
    width:30%;
}
#demo {
    width:100%;
    height: 100px;
}
.quizTimerIndecator{
    position:fixed;
    z-index: 9999999;
    bottom:45px;
    left:0px;
    width:0%;
    height:10px;
    background-color:#17b338;
     -o-transition:0.5s;
    -ms-transition:0.5s;
    -moz-transition:0.5s;
    -webkit-transition:0.5s;
    transition:0.5s;
}
.answerTab{
    cursor: pointer;
    margin-bottom: 10px;
    width:auto;
    padding: 0px 10px;
    min-height:40px;
    line-height: 40px;
    background-color: #d4dede;
    border-radius: 5px;
    -o-transition:0.5s;
    -ms-transition:0.5s;
    -moz-transition:0.5s;
    -webkit-transition:0.5s;
    transition:0.5s;
}
.answerTab:hover{
    background-color:#a1a1a1;
}
.quizTimer {
    position: fixed;
    background-color: #ffffff;
    color:#17b338;
    z-index: 999999;
    width:100%;
    height:45px;
    text-align: center;
    font-size: 32px;
    line-height: 45px;
    bottom: 0px;
    left:0px;
}
#signOutA{
    margin-left: 20px;
    cursor: pointer;
    font-size: 24px;
    line-height: 60px;
    float:right;
    color:#00000060;
}
#signOutA:hover{
    color:#000000;
}
.remText{
    font-size:12px;
    height:30px;
    line-height: 30px;
}
 .loginBarTitle{
    width:auto;
    padding: 20px;
    font-size:24px;
    text-align: center;
 }
 .starter{
    width:100%;
    overflow: auto; 
}
.starterIN {
    position: fixed;
    width:100%;
    height:100vh;
}
.loginInputs {
    padding: 20px;
    width:200px;
    border-radius: 10px;
    border:1px solid #cccccc;
    margin-bottom: 10px;
    text-align: center;
}
#popupI{
    cursor: pointer;
    font-size: 24px;
    padding:20px;
    color:#00000060;
    position:absolute;
    right:20px;
}
#popupI:hover {
    color:#000000;
}#popupIB{
    cursor: pointer;
    font-size: 24px;
    padding:20px;
    color:#00000060;
    position:absolute;
    left:20px;
}
#popupIB:hover {
    color:#000000;
}
.loginButton {
    cursor:pointer;
    padding: 20px;
    width:200px;
    background-color: #ff8c00;
    color:#ffffff;
    border-radius: 10px;
    border:0;
    margin-bottom: 10px;
}
.regButton {
    cursor:pointer;
    padding: 20px;
    width:200px;
    background-color: #08802e;
    color:#ffffff;
    border-radius: 10px;
    border:0;
    margin-bottom: 10px;
}
.loginButton:hover, .regButton:hover{
    background-color: #057ef0;
}
.passwordRuleText{
    font-size: 12px;
    color:#004711;
    line-height: 25px;
}
.errorMessage{
    width:100%;
    min-height: 30px;
    line-height: 30px;
    overflow: auto;
    font-size: 12px;
    font-weight: bold;
    color:#910000;
    text-align: center;
}
.header{
    position: fixed;
    z-index: 9999999;
    height: 60px;
    width:100%;
    top:0px;
    left:0px;
    color:#FFFFFF;
    background-color: #00529f;
    border-bottom: 1px solid #ffffff;
    border-radius: 0px 0px 20px 20px;
    box-shadow: 0px 0px 35px #000000;
}
.headerIn {
    width:90%;
    height:60px;
    line-height: 60px;
    margin-left: 5%;
}
.answerBtn {
    cursor: pointer;
     padding: 0px 10px;
    height:40px;
    line-height: 40px;
    color: #ffffff;
    background-color: #17b338;
    margin-left: auto;
    margin-right: auto;
    border:0px;
    border-radius: 6px;
    -o-transition:0.5s;
    -ms-transition:0.5s;
    -moz-transition:0.5s;
    -webkit-transition:0.5s;
    transition:0.5s;
}
.answerBtn:hover {
    background-color: #00529f;
}
.footer {

    margin-bottom: -30px;
    padding-top: 30px;
    color:#ffffff;
    font-size: 14px;
    width:100%;
    padding-bottom: 30px;
    background-color: #00529f;
    text-align: center;
}
.footer a{
    color:#ffffff;
    text-decoration: none;
}
@media only screen and (max-width:349px) {
    .noBoxLink, .BoxLink {
        margin-top: 10px;
        margin-bottom: 10px;
    }
    .loginInputs {
        width:150px;
        font-size: 12px;
        padding:10px;
        display: !important;
    }
    .block{
        display: block;
    }
    .loginBarTitle{
        font-size: 14px;
    }
    .selectorMobi {
        max-width: 60px;
        padding:0px;
        height:35px;
        font-size: 10px;
    }
    .loginBar{
        margin-top:25px;
        margin-bottom:25px;
        margin-right: auto;
        margin-left: auto;
        padding-bottom: 20px;
        background-color: #ffffff;
        border-radius: 25px;
        width:auto;
        max-width: 240px;
        height:auto;
    }
    .signupPopUp {
        width:240px;
        height:auto;
        z-index: 99;
        background-color: #ffffff;
        border-radius: 25px;
        margin-top:25px;
        margin-left: auto;
        margin-right: auto;
    }.quiz_terms_popup {
        display: none;
        position: fixed;
        width:240px;
        height:600px;
        margin-bottom: 15px;
        z-index: 999999999;
        font-size: 12px;
        background-color: #ffffff;
        border-radius: 25px;
        border:1px solid #00529f;
        top:50%;
        margin-top: -300px;
        bottom: 15px;
        left:50%;
        margin-left: -121px;
    }.new_message_popup {
        display: none;
        position: absolute;
        width:350px;
        height:540px;
        margin-top: -271px;
        z-index: 99;
        background-color: #ffffff;
        border-radius: 25px;
        border:1px solid #00529f;
        top:50%;
        left:50%;
        margin-left: -176px;
    }
     .messageInput {
        width:250px;
        margin-left: auto;
        margin-right: auto;
    }
    .messageTextarea {
        width:250px;
        height:200px;
    }
    .messagePOPTit{
        display: inline-block;
        width:300px;
        height:40px;
        margin-left: auto;
        margin-right: auto;
        text-align: center;
        color: #00529f;
        font-size: 12px;
        line-height:35px;
    }
    #taskRuls, #siteRuls{
        width:100%;
        height:300px;
    }
    .regiLine {
        width:240px;
        text-align: center;
        overflow: auto;
        margin-top: 50px;
        margin-left: auto;
        margin-right: auto;
    }
      .siteBody{
        margin-top:90px;
        width:95%;
        margin-left: auto;
        margin-right: auto;
        overflow: auto;
    }
    .siteLeft {
        width:100%;
        overflow: auto;
    }

    .siteRight {
        display: block;
    }
     .siteLeftIn{
        margin-bottom: 20px;
        width:auto;
        max-width:700px;
        margin-left: auto;
        margin-right: auto;
        overflow: auto;
        padding: 20px;
        border-radius: 12px;
    }
    .topHeadTit{
        display: none;
        cursor: pointer;
        float:left;font-size:8px;
    }
     .quizTitle{
        width:100%;
        margin-bottom: 10px;
        text-align: center;
        min-height: 32px;
        line-height: 32px;
        font-size:14px;
        border-bottom: 1px solid #00000029;
    }
    .task_detiles {
        width:100%;
        height:48px;
        line-height: 48px;
        font-size: 11px;
        font:gray;
    }
     .task_detiles span {
        width:50%;
        float: left;
    }
    .quizTitle button {
        cursor: pointer;
        display: block;
        margin-left: auto;
        margin-right: auto;
        border:0px;
        background-color: #ff7300;
        height:32px;
        border-radius: 6px;
        color: #ffffff;
        margin-bottom: 20px;
    }
    .quizTitle button:hover {
        background-color: #08802e;
    }
 }
@media only screen and (min-width:350px) and (max-width:1099px) { 
    .noBoxLink, .BoxLink {
        margin-top: 10px;
        margin-bottom: 10px;
    }
    .loginInputs {
        width:150px;
        font-size: 12px;
        padding:10px;
    }
    .block{
        display: block;
    }
    .loginBarTitle{
        font-size: 14px;
    }
    .selectorMobi {
        max-width: 60px;
        padding:0px;
        height:35px;
        font-size: 10px;
    }
    .loginBar{
        margin-top:25px;
        margin-bottom:25px;
        margin-right: auto;
        margin-left: auto;
        padding-bottom: 20px;
        background-color: #ffffff;
        border-radius: 25px;
        width:auto;
        max-width: 300px;
        height:auto;
    }
    .signupPopUp {
        
        width:300px;
        height:auto;
        margin-bottom: 15px;
        z-index: 99;
        background-color: #ffffff;
        border-radius: 25px;
        margin-top:25px;
        margin-right:auto;
        margin-left: auto;
    }.quiz_terms_popup {
        display: none;
        position: fixed;
        width:300px;
        height:600px;
        margin-bottom: 15px;
        z-index: 9999999999;
        font-size: 12px;
        background-color: #ffffff;
        border-radius: 25px;
        border:1px solid #00529f;
        top:50%;
        margin-top: -300px;
        bottom: 15px;
        left:50%;
        margin-left: -151px;
    }.new_message_popup {
        display: none;
        position: absolute;
        width:350px;
        height:540px;
        margin-top: -271px;
        z-index: 99;
        background-color: #ffffff;
        border-radius: 25px;
        border:1px solid #00529f;
        top:50%;
        left:50%;
        margin-left: -176px;
    }
     .messageInput {
        width:250px;
        margin-left: auto;
        margin-right: auto;
    }
    .messageTextarea {
        width:250px;
        height:200px;
    }
    .messagePOPTit{
        display: inline-block;
        width:300px;
        height:40px;
        margin-left: auto;
        margin-right: auto;
        text-align: center;
        color: #00529f;
        font-size: 12px;
        line-height:35px;
    }
    #taskRuls, #siteRuls{
        width:100%;
        height:300px;
    }
    .regiLine {
        width: auto;
        width:300px;
        text-align: center;
        justify-content: center;
        overflow: auto;
        margin-top: 50px;
        margin-left: auto;
        margin-right: auto;
    }
      .siteBody{
        margin-top:90px;
        width:95%;
        margin-left: auto;
        margin-right: auto;
        overflow: auto;
    }
    .siteLeft {
        width:320px;
        overflow: auto;
        margin-left: auto;
        margin-right: auto;
    }

    .siteRight {
        display: block;
    }
     .siteLeftIn{
        margin-bottom: 20px;
        width:auto;
        max-width:700px;
        margin-left: auto;
        margin-right: auto;
        overflow: auto;
        padding: 20px;
        border-radius: 12px;
    }
    .topHeadTit{
        cursor: pointer;
        float:left;font-size:12px;
    }
     .quizTitle{
        width:100%;
        margin-bottom: 10px;
        text-align: center;
        min-height: 32px;
        line-height: 32px;
        font-size:14px;
        border-bottom: 1px solid #00000029;
    }
    .task_detiles {
        width:100%;
        height:48px;
        line-height: 48px;
        font-size: 11px;
        font:gray;
    }
     .task_detiles span {
        width:50%;
        float: left;
    }
    .quizTitle button {
        cursor: pointer;
        display: block;
        margin-left: auto;
        margin-right: auto;
        border:0px;
        background-color: #ff7300;
        height:32px;
        border-radius: 6px;
        color: #ffffff;
        margin-bottom: 20px;
    }
    .quizTitle button:hover {
        background-color: #08802e;
    }
 }
@media only screen and (min-width:1100px) {

    .loginBar{
        margin-top:25px;
        margin-bottom: 25px;
        margin-left: auto;
        margin-right: auto;
        background-color: #ffffff;
        border-radius: 25px;
        padding-bottom: 20px;
        width:auto;
        max-width: 350px;
        height:auto;
    }
    .signupPopUp {
        display: none;
        position: absolute;
        width:800px;
        height:auto;
        padding-bottom: 15px;
        margin-bottom:15px;
        z-index: 99;
        background-color: #ffffff;
        border-radius: 25px;
        top:25px;
        left:50%;
        margin-left: -400px;
    }.quiz_terms_popup {
        display: none;
        position: absolute;
        width:800px;
        height:auto;
        margin-top:-225px;
        z-index: 99;
        background-color: #ffffff;
        border:1px solid #00529f;
        border-radius: 25px;
        top:50%;
        left:50%;
        margin-left: -401px;
    }.new_message_popup {
        display: none;
        position: absolute;
        width:800px;
        height:440px;
        margin-top: -221px;
        z-index: 99;
        border:1px solid #00529f;
        background-color: #ffffff;
        border-radius: 25px;
        top:50%;
        left:50%;
        margin-left: -401px;
    }
    .messageInput {
        width:700px;
        margin-left: auto;
        margin-right: auto;
    }
    .messageTextarea {
        width:700px;
        height:110px;
    }
    .messagePOPTit{
        display:inline-block;
        width:700px;
        height: 40px;
        margin-left:auto;
        margin-right:auto;
        text-align: center;
        color: #00529f;
        font-size: 16px;
        line-height:40px
    }
      #taskRuls, #siteRuls{
        width:90%;
        height:400px;
    }
    .regiLine {
        width:492px;
        overflow: auto;
        margin-top: 50px;
        margin-left: auto;
        margin-right: auto;
    }
    .siteBody{
        margin-top:90px;
        width:95%;
        margin-left: auto;
        margin-right: auto;
        overflow: auto;
    }
    .siteLeft {
        float: left;
        width:65%;
        overflow: auto;
    }

    .siteRight {
        float: right;
        width:30%;
        overflow: auto;
    }
    .siteLeftIn{
        width:100%;
        max-width:700px;
        margin-left: auto;
        margin-right: auto;
        margin-bottom: 20px;
        overflow: auto;
        padding: 20px;
        border-radius: 12px;
    }
    .topHeadTit{
        float:left;font-size:32px
    }
    .quizTitle{
        width:100%;
        height: 48px;
        line-height: 48px;
        font-size:16px;
        margin-bottom: 10px;
        border-bottom: 1px solid #00000029;
    }
    .quizTitle button {
        cursor: pointer;
        float:right;
        border:0px;
        background-color: #ff7300;
        height:32px;
        border-radius: 6px;
        color: #ffffff;
    }
    .quizTitle button:hover {
        background-color: #08802e;
    }
    .task_detiles {
        width:100%;
        height:48px;
        line-height: 48px;
        font-size: 11px;
        font:gray;
    }
    .task_detiles span {
        width:25%;
        float: left;
    }
    .profileTab {
        display: table;
        width:100%;
        overflow: auto;
        height:auto;
    }
    .profileTr{
        display: table-row;
        width:auto;
        height:auto;
    }
    .profileTdL {
        display: table-cell;
        height:80px;
        vertical-align: middle;
        width:45%;
    }
    .profileTdR {
        display: table-cell;
        height:80px;
        vertical-align: middle;
        width:55%;
    }
}
.quiz_answer_h {
    background-color: #acedfa;
    width:auto;
    padding-left: 10px;
    min-height: 30px;
    line-height: 30px;
    margin-bottom: 10px;
    border-radius: 5px;
}.quiz_answer {
    background-color: #fff;
    width:auto;
    padding-left: 10px;
    min-height: 30px;
    line-height: 30px;
    margin-bottom: 10px;
    border-radius: 5px;
}
</style>