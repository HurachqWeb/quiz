<div id="new_message" class="new_message_popup">
	<div class="quiz_popup_in">
	  	<form id="mesForm" onsubmit="return messageSend()" action="func/mesSend.php"  method="post" enctype="multipart/form-data">
			<i class="fa fa-close" style="position:absolute;right:20px;cursor:pointer;font-size: 24px;"  onclick="startNewMessage()"></i>
		<p>
			<p id="messagers"></p>
		 	<center>ԿԱՊ ՄԵԶ ՀԵՏ</center>
		 	<p>
		 <center>	<input type="text" id="title" name="title" class="loginInputs messageInput" placeholder="Վերնագիրը">
		 <p>
		 	<textarea id="text" name="text" class="loginInputs messageTextarea" placeholder="Նամակի տեքստը"></textarea>
		 	<p>Կցել ֆայլ <input type="file" id="file" name="file" placeholder="Ընտրեք ֆայլը" >
		 	<button id="startQuizbtn" class="regButton" onclick="messageSend()" >ՈՒՂԱՐԿԵԼ</button>
		 </form>
		 </center>
	</div>
</div>
<div id="read_message" class="new_message_popup">
	<div class="quiz_popup_in">
		<i class="fa fa-close" style="position:absolute;right:20px;cursor:pointer;font-size: 24px;"  onclick="readMessage('0')"></i>
		<p>
		<div id="meassageLodaer" style="width:90%;margin-left:auto;margin-right:auto;height:380px;overflow-y: scroll;"></div>
	</div>
</div>
<div class="siteBody">
	<div class="siteLeft">
			<div class="siteLeftIn" style="background-color: #FFFFFF;">
		  	<div class="quizTitle"><?=@$text_messages?>
		  		<button id="startbtn" onclick="startNewMessage()"><?=@$text_new_message?></button>
		  	</div>
		  	<div class="quizTitle" style="min-height:40px">
		  		<?php
		  			if(@$_GET['box'] == "inbox"){
		  				echo "<span class=\"noBoxLink\">ՄՈՒՏՔԱՅԻՆ</span> <span class=\"BoxLink\" onclick=\"location.href='".@$domain."index.php?page=messages&box=outbox'\">ԵԼՔԱՅԻՆ</span>";
		  			}
		  			if(@$_GET['box'] == "outbox"){
		  				echo "<span class=\"BoxLink\"  onclick=\"location.href='".@$domain."index.php?page=messages&box=inbox'\">ՄՈՒՏՔԱՅԻՆ</span> <span class=\"noBoxLink\">ԵԼՔԱՅԻՆ</span>";
		  			}
		  		?>
		  	</div>
		  	<?php
		  		if(@$_GET['box'] == "inbox"){
		  			@$qr = "select * from messages where for_user='".@$profile."' and user_to='".@$profile."' order by id desc";
		  		}
		  		if(@$_GET['box'] == "outbox"){
		  			@$qr = "select * from messages where for_user='".@$profile."' and user_from='".@$profile."' order by id desc";
		  		}
		  		@$rs=mysqli_query($db,$qr);
		  		@$kl=mysqli_num_rows($rs);
		  		if($kl == 0){
		  			echo "<p style=\"text-align:center\">".@$text_no_message."</p>";
		  		}
		  		else {
		  			for($i=1;$i<=$kl;$i++){
		  				@$rw=mysqli_fetch_array($rs);
		  				@$dat = @$rw['added'];
		  				echo "<div class=\"messageDiv\" onclick=\"readMessage(".@$rw['id'].")\"><span class=\"messageDate\">".dataPrint($dat)."</span> | <span class=\"messageTitle\">"
		  				.@$rw['title']."</span></div>";
		  			}
		  		}
		  	?>
		  </div>
		
	</div>
		<div class="siteRight"></div>
</div>
<script type="text/javascript">
	function startNewMessage(){
		if(document.getElementById("new_message").style.display == "none")
		{
			document.getElementById("new_message").style.display="block";
		}
		else
		{
			document.getElementById("new_message").style.display="none";
		}
	}
</script>
<script type="text/javascript">
	function readMessage(mesID){
		if(document.getElementById("read_message").style.display == "none")
		{
			document.getElementById("read_message").style.display="block";


			const http = new XMLHttpRequest();
			var urlThe = "<?=@$domain?>/inc/readMessage.php?id="+mesID;            
    		http.open("GET", urlThe);
    		http.send();
    		http.onload = () => document.getElementById("meassageLodaer").innerHTML=http.responseText;
		}
		else
		{
			document.getElementById("read_message").style.display="none";
			document.getElementById("meassageLodaer").innerHTML="";
		}
	}
</script>
<script type="text/javascript">
	function messageReply(){
				document.getElementById("mesFormRep").submit();
	}
</script>