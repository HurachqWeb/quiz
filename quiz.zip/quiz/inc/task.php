<?php
@session_start();
@include "../config.php";

@$profile = @$_SESSION['user_id'];
if(!@$profile)
{
	@$profile = @$_COOKIE['user_id'];
}
	
	@$qr_check = "select * from quizes_answers where user_id='".@$profile."' and quiz_id='".@$_GET['id']."'";
	@$rs_check = mysqli_query($db,$qr_check);
	@$rw_check = mysqli_fetch_array($rs_check);


	@$last_ansfered_task=@$rw_check['last_ansfered_task'];


	if(@$_GET['answer'] > 0)
	{
		
		@$new_last=@$_GET['last']+1;
		@$mls=9-@$_GET['mls'];
		@$taskID  = "task_".@$new_last;
		@$qrp="SELECT id FROM `tasks` where id='".@$rw_check[$taskID]."' and right_answer_variant='".@$_GET['answer']."' ";
		@$rsp=mysqli_query($db,$qrp);
		@$klp=mysqli_num_rows($rsp);
		
		if($klp == 1){
			@$new_point = @$rw_check['points']+1;
		}else{
			@$new_point = @$rw_check['points'];
		}
		@$qr_up = "update quizes_answers set last_ansfered_task='".@$new_last."', answer_".@$new_last."='".@$_GET['answer']."', mil_secs='".@$mls."', points='".@$new_point."',now_sec='15' where user_id='".@$profile."' and quiz_id='".@$_GET['id']."'";
		mysqli_query($db,@$qr_up);
		
		echo "<META HTTP-EQUIV='Refresh' CONTENT='0; URL=".@$domain."index.php?page=quiz&id=".@$_GET['id']."'>";
		exit;
	}

	@$tasks = array('0'=>"task_1",'1'=>"task_2",'2'=>"task_3",'3'=>"task_4",'4'=>"task_5",'5'=>"task_6",'6'=>"task_7",'7'=>"task_8",'8'=>"task_9",'9'=>"task_10");
	@$task_id=@$rw_check[@$tasks[@$last_ansfered_task]];

	@$qr="SELECT * FROM `tasks` where id='".@$task_id."'";
	@$rs=mysqli_query($db,$qr);
	@$rw=mysqli_fetch_array($rs);

	if(@$rw_check['last_ansfered_task'] < 10)
	{
	echo "
	<input type=\"hidden\" id=\"last_ansfered_task\" value=\"".@$rw_check['last_ansfered_task']."\">
	<input type=\"hidden\" id=\"answer_variant\" value=\"\">
	<p style=\"font-size:18px\"># ".str_ireplace('task_', '', @$tasks[@$last_ansfered_task])."/10<br>".@$rw['title_am']."</p>";
	if($rw['img_1']){
		echo "<center><img src=\"uploads/answer/".$rw['img_1']."\" class=\"taskIMG\"></center><p>";
	}
	if(@$rw['answer_variant_1_am'] != null){
		echo "<div id=\"asnwer_1\" onclick=\"selectvariant('1')\" ondblclick=\"taskAnswer()\" class=\"answerTab\">A. ".@$rw['answer_variant_1_am']."</div>";
	}
	if(@$rw['answer_variant_2_am'] != null){
		echo "<div id=\"asnwer_2\" onclick=\"selectvariant('2')\" ondblclick=\"taskAnswer()\"  class=\"answerTab\">B. ".@$rw['answer_variant_2_am']."</div>";
	}
	if(@$rw['answer_variant_3_am'] != null){
		echo "<div id=\"asnwer_3\" onclick=\"selectvariant('3')\" ondblclick=\"taskAnswer()\"  du class=\"answerTab\">C. ".@$rw['answer_variant_3_am']."</div>";
	}
	if(@$rw['answer_variant_4_am'] != null){
		echo "<div id=\"asnwer_4\" onclick=\"selectvariant('4')\" ondblclick=\"taskAnswer()\"  class=\"answerTab\">D. ".@$rw['answer_variant_4_am']."</div>";
	}
	if(@$rw['answer_variant_5_am'] != null){
		echo "<div id=\"asnwer_5\" onclick=\"selectvariant('5')\" ondblclick=\"taskAnswer()\"  class=\"answerTab\">E. ".@$rw['answer_variant_5_am']."</div>";
	}
	if(@$rw['answer_variant_6_am'] != null){
		echo "<div id=\"asnwer_6\" onclick=\"selectvariant('6')\" ondblclick=\"taskAnswer()\"  class=\"answerTab\">F. ".@$rw['answer_variant_6_am']."</div>";
	}
	echo "<center><button id=\"answerBtn\" class=\"answerBtn\" onclick=\"taskAnswer()\">ՀԱՍՏԱՏԵԼ ՊԱՏԱՍԽԱՆԸ</button></center>";
	}
	else {
		echo "<center><i class=\"fa fa-check\" aria-hidden=\"true\" style=\"font-size:64px;color:#17b338;\"></i>
</center><p style=\"text-align:center\">Շնորհակալություն Քուիզին մասնակցելու համար։<br> 
Հետևեք կայքի թարմացումներին:<br>
Hala Madrid y Nada Mas</p><p  style=\"text-align:center\">Քուիզի արդյունքների մասին և նոր քուիզերի մեկնարկի մասին կարող եք առաջինը տեղեկանալ հետևելով մեր տելեգրամ ալիքին։<br><a href=\"https://t.me/realmadridamofficial\" target=\"_blank\">Միանալ Տելեգրամ ալիքին</a>
</p>";

	}

?>