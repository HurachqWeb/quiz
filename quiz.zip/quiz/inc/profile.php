<?php
@$qr = "select avatar, username, name, last_name, birthday, email_address,phone_number from users where id='".@$profile."'";
@$rs = mysqli_query($db,$qr);
@$rw = mysqli_fetch_array($rs);

@$birthday = @$rw['birthday'];
@$birthday = explode('-', $birthday);
if(!@$rw['avatar']){
	@$avatar = "";
}
else
{
	@$avatar = $domain."uploads/avatars/200x200/".@$rw['avatar'];
	
}
?>
<link href="<?=$domain?>_inside/dropzone/dist/dropzone.css" rel="stylesheet" type="text/css">
<link href="<?=$domain?>_inside/dropify/css/dropify.min.css" rel="stylesheet">
<div class="siteBody">
	<div class="siteLeft">
		
		<div class="siteLeftIn" style="background-color: #FFFFFF;">
			<div class="quizTitle"><?=@$text_profile_edit?>
				
				<button id="startbtn" onclick="location.href='<?=$domain?>index.php'">ՄԱՍՆԱԿՑԵԼ ՔՈՒԻԶԻ</button>
			</div>
			<form onsubmit="return saveProfile()" id="myForm" action="saveProfile.php" method="POST" enctype="multipart/form-data">
			<div class="profileTab">
				<div class="profileTr">
					<div class="profileTdL"><?=@$text_avatar?></div>
					<div class="profileTdR">
						<div style="width:300px;height:auto;margin-top:10px"><input type="file" name="avatar" class="dropify" data-default-file="<?=@$avatar?>"></div>
					</div>
				</div>
				<div class="profileTr">
					<div class="profileTdL"><?=@$text_login?></div>
					<div class="profileTdR"><input type="text" class="loginInputs" maxlength="32" value="<?=@$rw['username']?>" disabled/></div>
				</div>
				<div class="profileTr">
					<div class="profileTdL"><?=@$text_name?></div>
					<div class="profileTdR"><input type="text" name="name" id="name" class="loginInputs" maxlength="32" value="<?=@$rw['name']?>" disabled/></div>
				</div>
				<div class="profileTr">
					<div class="profileTdL"><?=@$text_lastname?></div>
					<div class="profileTdR"><input type="text" name="last_name" id="last_name" class="loginInputs" maxlength="32" value="<?=@$rw['last_name']?>" disabled/></div>
				</div>
				<div class="profileTr">
					<div class="profileTdL"><?=@$text_birthday2?></div>
					<div class="profileTdR">
						<select name="birth_day" class="loginInputs" style="width:30%;" disabled/>
				<option value="">Օր</option>
				<?php
					for(@$d=1;$d<=31;$d++){
						if($d<=9){
							@$day="0".$d;
						}else{
							@$day=$d;
						}
						echo "<option value=\"".@$day."\" "; if($day == $birthday[2]){ echo "selected/";} echo">".@$day."</option>";
					}
				?>
			</select>
			<select name="birth_mounth" class="loginInputs" style="width:30%;" disabled/>
				<option value="">Ամիս</option>
				<option value="01" <?php if(@$birthday[1] == "01"){ echo "selected/";} ?>>հունվար</option>
				<option value="02" <?php if(@$birthday[1] == "02"){ echo "selected/";}?>>փետրվար</option>
				<option value="03" <?php if(@$birthday[1] == "03"){ echo "selected/";}?>>մարտ</option>
				<option value="04"  <?php if(@$birthday[1] == "04"){ echo "selected/";}?>>ապրիլ</option>
				<option value="05"  <?php if(@$birthday[1] == "05"){ echo "selected/";}?>>մայիս</option>
				<option value="06"  <?php if(@$birthday[1] == "06"){ echo "selected/";}?>>հունիս</option>
				<option value="07"  <?php if(@$birthday[1] == "07"){ echo "selected/";}?>>հուլիս</option>
				<option value="08"  <?php if(@$birthday[1] == "08"){ echo "selected/";}?>>օգոստոս</option>
				<option value="09"  <?php if(@$birthday[1] == "09"){ echo "selected/";}?>>սեպտեմբեր</option>
				<option value="10"  <?php if(@$birthday[1] == "10"){ echo "selected/";}?>>հոկտեմբեր</option>
				<option value="11" <?php if(@$birthday[1] == "11"){ echo "selected/";}?>>նոյեմբեր</option>
				<option value="12" <?php if(@$birthday[1] == "12"){ echo "selected/";}?>>դեկտեմբեր</option>
			</select>
			<select name="birth_year" class="loginInputs" style="width:30%;" disabled/>
				<option value="">Տարի</option>
				<?php 
					for($s=1;$s<=70;$s++){
						@$yr=date('Y')-10;
						@$year = $yr-$s;
						echo "<option value=\"".@$year."\"";if($year == @$birthday[0]){ echo " selected/";}echo">".@$year."</option>";
					}
				?>
			</select>
					</div>
				</div>
				<div class="profileTr">
					<div class="profileTdL"><?=@$text_phone?></div>
					<div class="profileTdR">+374<input type="text" name="phone_number" id="phone_number" class="loginInputs" maxlength="8" value="<?=str_ireplace('+374', '', @$rw['phone_number'])?>"  onkeypress="checkPhone(event)" disabled/>
						<p id="profError"></p>
					</div>
				</div>
				<div class="profileTr">
					<div class="profileTdL"><?=@$text_email?></div>
					<div class="profileTdR"><input type="text" name="email_address" id="email_address" class="loginInputs" maxlength="32" value="<?=@$rw['email_address']?>">
						<?php 
				if(!@$rw['email_address'])
				{
				?>
				<p style="color:#910000;font-size:11px"><?=@$text_email_warn?></p>
				
	
				<?php
				}
				?>
					</div>
				</div>
				
			</div>
			
				
				<center><button class="regButton" onclick="saveProfile()"><?=@$text_save?></button></center>
				</form>
		</div>
		<div class="siteLeftIn" style="background-color: #FFFFFF;">
			<div class="quizTitle"><?=@$text_password_edit?></div>
			<p id="passwordFinish"></p>
			<div class="profileTab">
				<div class="profileTr">
					<div class="profileTdL"><?=@$old_password?></div>
					<div class="profileTdR"><input type="password" name="old_password" id="old_password" class="loginInputs" maxlength="16" onkeyup="checkPasswordProfile()">
						<p id="pssError"></p>
					</div>
				</div>
				<div class="profileTr">
					<div class="profileTdL"><?=@$new_password?></div>
					<div class="profileTdR"><input type="password" name="new_password" id="new_password" class="loginInputs" maxlength="16" onkeyup="checkNewPass()" onkeypress="checkPassOfPreg2(event)">
						<p id="pssError2"></p>
					</div>
				</div>
				<div class="profileTr">
					<div class="profileTdL"><?=@$repeat_password?></div>
					<div class="profileTdR"><input type="password" name="repeat_password" id="repeat_password" class="loginInputs" maxlength="16"  onkeyup="checkReptPass()" >
						<p id="pssError3"></p>
					</div>
				</div>
			</div>
			<center><button class="regButton" onclick="changePassword()"><?=@$text_save?></button></center>
		</div>
	</div>
	<div class="siteRight"></div>
</div>
<script src="<?=$domain?>_inside/dropzone/dist/dropzone.js"></script>
    <script src="<?=$domain?>dropify.min.js"></script>
    <script src="<?=$domain?>_inside/jquery.dropzone.init.js"></script>