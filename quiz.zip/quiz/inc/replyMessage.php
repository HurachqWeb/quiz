<?php
@session_start();

include "../config.php";
@$profile = @$_SESSION['user_id'];
if(!@$profile)
{
	@$profile = @$_COOKIE['user_id'];
}

	@$qr = "select * from messages where id='".@$_POST['id']."'";
	@$rs = mysqli_query($db,$qr);
	@$rw = mysqli_fetch_array($rs);
	@$date = date('Y-m-d H:i:s',$time);
	@$title = "[RE: ".@$rw['title']."]";
	@$text = strip_tags($_POST['textR']);
	@$text = nl2br($text);
	@$text = @$text."<p>[QUITE]".@$rw['message']."[/QUITE]]";
	@$qr1 = "insert into messages value(null,'".@$date."','".@$profile."','".@$profile."','admin','".@$title."','".@$text."','new')";
	@$qr2 = "insert into messages value(null,'".@$date."','admin','".@$profile."','admin','".@$title."','".@$text."','new')";
	mysqli_query($db,$qr1);
	mysqli_query($db,$qr2);

	if(@$_FILES['fileR']['name']){
		@$filename = rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9);
		@$filename = MD5($filename);
		@$upload_dir = "../uploads/attached_files/";
		$fileNameNow = @$filename."-".@$_FILES['fileR']['name'];
		move_uploaded_file($_FILES['fileR']['tmp_name'], "$upload_dir/$fileNameNow");
		@$qr_attach = "insert into attached_file values(null,'".@$date."','".@$profile."','admin','".$fileNameNow ."')";
		mysqli_query($db,$qr_attach);

	}
	else{
		
	}
echo "<META HTTP-EQUIV='Refresh' CONTENT='0; URL=".@$domain."index.php?page=messages&box=outbox'>";

?>