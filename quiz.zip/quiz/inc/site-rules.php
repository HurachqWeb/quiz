<?php
@include "../config.php";
@$qr="select content_text from site_rules where id='1'";
@$rs=mysqli_query($db,$qr);
@$rw=mysqli_fetch_array($rs);
echo @$rw['content_text'];
?>

