<div id="signOBar" style="display:none"></div>
<div class="header">
<div class="headerIn">
	<img src="<?=$domain?>/_inside/images/rm_logo.png" onclick="location.href='<?=$domain?>'" style="cursor: pointer;float:left;height:40px;margin-top:10px;margin-right:20px">
	<span class="topHeadTit" onclick="location.href='<?=$domain?>'">QUIZ.REALMADRID.AM</span>
	<i id="signOutA" class="fa fa-sign-out" aria-hidden="true" title="<?=@$TextLogOut?>" onclick="signOut()"></i>
	<i id="signOutA" class="fa fa-user" aria-hidden="true" onclick="location.href='<?=@$domain?>index.php?page=profile'" title="<?=@$myProfile?>"></i>
	<i id="signOutA" class="fa-solid fa-message" aria-hidden="true" onclick="location.href='<?=@$domain?>index.php?page=messages&box=inbox'" title="<?=@$myProfile?>"></i>
</div>
</div>