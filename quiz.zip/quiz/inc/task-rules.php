<?php
include "../config.php";
@$qr="select content_text from quizes_rules where quiz_id='".@$_GET['id']."' order by id desc limit 1";
@$rs=mysqli_query($db,$qr);
@$rw=mysqli_fetch_array($rs);
echo @$rw['content_text'];
?>

