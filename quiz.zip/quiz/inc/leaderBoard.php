<?php

if(!$_GET['id'])
{
	@$qr = "select * from quizes where status='finished' order by id desc";
}
else
{
	@$qr = "select * from quizes where status='finished' and id='".@$_GET['id']."' order by id desc";
}

@$rs=mysqli_query($db,$qr);
@$kl=mysqli_num_rows($rs);
@$rw=mysqli_fetch_array($rs);

@$qr_1 = "select * from LEADERBOARD where quiz_id='".@$rw['id']."' and user_id='".@$profile."' order by position asc limit 100";

@$rs_1 = mysqli_query(@$db,$qr_1);
@$kl_1 = mysqli_num_rows($rs_1);
if($kl > 0){
echo "<h1>ՁԵՐ ԴԻՐՔԸ</h1>";
echo "<h1>".@$rw['title_am']."</h1>";
echo "<div class=\"liderboard_header\">
		<div id=\"position\"><span title=\"Զբաղեցրած տեղը\">#</span></div>
		<div id=\"username\">Օգտատեր</div>
		<div id=\"points\"><span title=\"Ճշգրիտ պատասխաններ\">ՃՊ</span></div>
		<div id=\"time\"><span title=\"Ժամանակը\">ԺՄ</span></div>
	</div>";

for(@$i=1;$i<=$kl_1;$i++){
	@$rw_1=mysqli_fetch_array($rs_1);

	if(@$rw_1['prizer'] == "winner")
	{
		@$aditional_color="background-color:gold";
	}else{
		if($rw_1['prizer'] == "yes")
		{
			if(@$rw_1['position'] <=6){
				@$aditional_color="background-color:silver";
			}else{
				@$aditional_color="background-color:#CD7F32";
			}
		}else {
			@$aditional_color="background-color:#FFFFFF";
		}
	}
	@$timers = @$rw_1['seconds'];
	
	@$qr_user = "select username from users where id ='".@$rw_1['user_id']."'";
	@$rs_user = mysqli_query($db,$qr_user);
	@$rw_user = mysqli_fetch_array($rs_user);
	echo "<div class=\"liderboard_li\" style=\"".@$aditional_color."\">
		<div id=\"position\">".@$rw_1['position']."</div>
		<div id=\"username\">".@$rw_user['username']."</div>
		<div id=\"points\">".@$rw_1['points']."</div>
		<div id=\"time\">".timerStop(@$timers).":";
		if(@$timers < 150){
			echo @$rw_1['milisecond'];
		}
		else {
			echo "0";
		}
		echo"</div>
	</div>";
}
}
?>