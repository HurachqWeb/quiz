
<div class="footer">
	<a href="<?=$domain?>tc.php">Դրույթներ և Պայմաններ</a>
</div>
