<!DOCTYPE html>
<html lang="en">
 <head>
 	<?php
 	@$qr="SELECT * FROM `settings` order by id desc limit 1";
 	@$rs=mysqli_query($db,$qr);
 	@$rw=mysqli_fetch_array($rs);
 	?>
 <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="audience" content="all">
    <meta name="rating" content="general">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, minimal-ui">
    <meta name="google-adsense-account" content="ca-pub-5286784049875629">
    <meta name="theme-color" content="#FFFFFF">
    <meta name="msapplication-navbutton-color" content="#FFFFFF">
    <meta name="apple-mobile-web-app-status-bar-style" content="#FFFFFF">
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
    <meta name="description" content="<?=@$rw['site_discreption']?>" />
    <meta name="keywords" content="<?=@$rw['site_keywords']?>">
    <link rel="shortcut icon" href="//<?=$_SERVER['HTTP_HOST']?>/uploads/files/<?=@$rw['favicon']?>">
    <meta property="og:locale" content="en" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?=@$rw['site_title']?>" />
    <meta property="og:description" content="<?=@$rw['site_discreption']?>"/>
    <meta property="og:image" content="//<?=$_SERVER['HTTP_HOST']?>/uploads/files/<?=@$rw['large_image']?>" />
    <meta property="og:url" content="" />
    <meta property="og:site_name" content="<?=@$rw['site_title']?>" />
    <meta name="format-detection" content="telephone=no">
    <title><?=@$rw['site_title']?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2496987352174355"  crossorigin="anonymous"></script>
    <?php include "css.php"?>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PPQXDXNV');</script>
<!-- End Google Tag Manager -->
 </head>

 	