<div class="siteBody">
	<div class="siteLeft">
		<div id="quizStart"></div>
		<?php
		@$status_text = array('nopublish'=>"Չհրապարակված",'active'=>"Ակտիվ",'pasive'=>"Պասիվ",'finished'=>"ավարտված");
		 function datPrint($dat){
		 	@$months = array('01'=>"հնվ․",'02'=>"փետ․",'03'=>"մարտ",'04'=>"ապր․",'05'=>"մայ․",'06'=>"հնս․",'07'=>"հլս․",'08'=>"օգս․",'09'=>"սեպ․",'10'=>"հոկ․",'11'=>"նոյ․",'12'=>"դեկ․");
		 	@$datchek = explode(' ', $dat);
		 	@$date = @$datchek[0];
		 	@$time = @$datchek[1];
		 	@$print_time = $time[0].$time[1].$time[2].$time[3].$time[4];

		 	@$print_date = explode('-',@$date);

		 	@$result= @$print_date[2]." ".@$months[@$print_date[1]]." ".@$print_date[0]." | ".@$print_time;
		 	return $result;
		 }
		
			@$qr="select * from quizes where id='".@$_GET['id']."' order by status asc, id desc";
			@$rs=mysqli_query($db,$qr);
			@$kl=mysqli_num_rows($rs);
			 @$color_style= array('active'=>"#FFFFFF",'finished'=>"#FFFFFF",'pasive'=>"#d4dede");
			
				@$rw=mysqli_fetch_array($rs);
				@$chek_qr = "select * from quizes_answers where quiz_id='".@$rw['id']."' and user_id='".@$profile."'";
				@$check_rs = mysqli_query($db, $chek_qr);
				@$check_kl = mysqli_num_rows($check_rs);
				if(@$check_kl == 0){
					echo "<META HTTP-EQUIV='Refresh' CONTENT='0; URL=".@$domain."'>";
					exit;
				}
					@$check_rw = mysqli_fetch_array($check_rs);
				
			


		?>
			<div class="siteLeftIn" style="background-color: <?=@$color_style[@$rw['status']]?>;">
				<div class="quizTitle"><?=@$rw['title_am']?>
				</div>
				<div class="task_detiles">
					<span><i class="fa fa-clock"></i>
 <b><?=datPrint(@$rw['start_date'])?></b></span>
					<span><i class="fa fa-flag-checkered" aria-hidden="true"></i>
 <b><?=datPrint(@$rw['end_date'])?></b></span>
					<span><?=@$status_text[@$rw['status']];?></span>
					<span><?php 
					if(@$check_kl > 0 && @$rw['status'] == "active"){
						@$timers = @$check_rw['start_sec'];

						if($timers >= 149){
							@$timers = 150;
						}
						echo "<div style=\"line-height:20px\"><font style=\"color:green\">".@$check_rw['points']."/10</font><br>".timerStop(@$check_rw['start_sec']).":".@$check_rw['mil_secs'];
						if(@$timers < 150){
								echo @$check_rw['mil_secs'];
						}
						else {
							echo "0";
						}
						echo"</div>";
					}
					?></span>
				</div>
			</div>
		
		   <div id="tasks" class="siteLeftIn" style="background-color: <?=@$color_style[@$rw['status']]?>;">
		   	<?php


		   		include "task.php";

		   	?>
		   </div>
		   <?php
		   @$qr_check = "select id from quizes_answers where user_id='".@$profile."' and quiz_id='".@$_GET['id']."'";
			@$rs_check = mysqli_query($db,$qr_check);
			@$kl_check = mysqli_num_rows($rs_check);
			@$qr_check_status = "select id from quizes where id='".@$_GET['id']."' and status='finished'";
			@$rs_check_status = mysqli_query($db,@$qr_check_status);
			@$kl_check_status = mysqli_num_rows(@$rs_check_status);
			/*if($kl_check > 0 && @$kl_check_status > 0){
					   echo "
					   <div class=\"siteLeftIn\">
					   <h1>".@$text_your_answers."</h1>
					   ";
					  include "inc/quiz-report.php";
					   echo "</div>";
					 }*/
		   ?>
	</div>

	<div class="siteRight"><?php include "inc/leaderBoard.php";?></div>
</div>
<?php 
if(@$check_rw['start_sec'] < 151)
{
?>
<div id="quizTimerIndecator" class="quizTimerIndecator"></div>
 
<div class="quizTimer">
<?php 
if(@$check_rw['last_ansfered_task'] != 10){
	?>
00:<span id="answerTimer">15<?php /*if(@$check_rw['now_sec'] == 0) {echo "15";}else{if(@$check_rw['now_sec'] <10){echo "0";}echo @$check_rw['now_sec'];}*/?></span> |
<?php 
}
?>
	<span id="quizTimer"><?php 

if(@$check_rw['last_ansfered_task'] != 10){
@$nowMinute = @$check_rw['start_sec'];
}else{
    $nowMinute = @$check_rw['start_sec']+1;
}
echo timerStop($nowMinute);
?></span><span id="milSecDots">:</span><?php if(@$check_rw['last_ansfered_task'] != 10){?><span id="millsec">0</span><?php }else{ echo @$check_rw['mil_secs'];}?></div>
<?php
}
?>
<script type="text/javascript">
	const ast = setInterval(function(){
		let as = document.getElementById("answerTimer").innerHTML;
		let as_n = Number(as)-Number(1);
		if(as_n >= 10){
				document.getElementById("answerTimer").innerHTML=as_n;}else{
				document.getElementById("answerTimer").innerHTML="0"+as_n;}
		if(as_n == "00")
		{
			
			
		
			var quiz = "<?=@$_GET['id']?>";
			var answ = "7";
			var lst = document.getElementById("last_ansfered_task").value;
			var miles = document.getElementById("millsec").innerHTML;
			document.getElementById("quizTimerIndecator").style.width="100%";
			document.getElementById("quizTimerIndecator").style.backgroundColor="red";
			const http2 = new XMLHttpRequest();
			var urlThe2 = "<?=@$domain?>/inc/task.php?id="+quiz+"&answer="+answ+"&last="+lst+"&mls="+miles;            
    		http2.open("GET", urlThe2);
    		http2.send();
    		http2.onload = () => document.getElementById("tasks").innerHTML=http2.responseText;
    			
		}
	},1000);
</script>
<script>
    const milInterval = setInterval(function(){
        var aa = document.getElementById("last_ansfered_task").value;
        var aaa =Number(aa)+Number(1);
        if(aaa === 11){
        	clearInterval(milInterval);
        }
        var dd = document.getElementById("millsec").innerHTML;
        var nn = Number(dd)+Number(1);
        if(nn === 10)
        {
            document.getElementById("millsec").innerHTML = 0;
        }
        else{
            document.getElementById("millsec").innerHTML = nn;
        }
        
    },100);
</script>
<script type="text/javascript">
	var timervar =setInterval(timerStart,1000);
	function timerStart() {
		const http = new XMLHttpRequest();
		var answ = document.getElementById("answerTimer").innerHTML;
		var urlThe = "<?=@$domain?>/func/timer.php?id=<?=@$_GET['id']?>&secanswer="+answ;            
    	http.open("GET", urlThe);
    	http.send();
    	http.onload = () => document.getElementById("quizTimer").innerHTML=http.responseText;
    
	}
</script>
<script type="text/javascript">
	setInterval(function(){
		var now_sec = document.getElementById("answerTimer").innerHTML;
		var realSec = Number(15)-Number(now_sec);
		var precent2 = Number(realSec)*Number(100);
		var precent = Number(precent2)/Number(15);
		document.getElementById("quizTimerIndecator").style.width=precent+"%";
		if(precent == 100){
			document.getElementById("quizTimerIndecator").style.backgroundColor="red";
		}
	},100);
</script>
<script type="text/javascript">
	function selectvariant(d){
		let ds = document.getElementById("answer_variant").value;
		document.getElementById("answer_variant").value=d;
		let sel2 = "asnwer_"+ds;
		let sel = "asnwer_"+d;
		if(ds > 0){
			document.getElementById(sel2).style.color="#000000";
			document.getElementById(sel2).style.backgroundColor="#d4dede";
		}
		document.getElementById(sel).style.color="#FFFFFF";
		document.getElementById(sel).style.backgroundColor="#17b338";
	}
</script>
<script type="text/javascript">
	function taskAnswer(){
		
		var quiz = "<?=@$_GET['id']?>";
		var answ = document.getElementById("answer_variant").value;
		var lst = document.getElementById("last_ansfered_task").value;
		var miles = document.getElementById("millsec").innerHTML;
		const http = new XMLHttpRequest();
		var urlThe = "<?=@$domain?>/inc/task.php?id="+quiz+"&answer="+answ+"&last="+lst+"&mls="+miles;            
    	http.open("GET", urlThe);
    	http.send();
    	http.onload = () => document.getElementById("tasks").innerHTML=http.responseText;
	}
</script>
<div id="demo">&nbsp;</div>