<div id="starter" class="starter">

		<div class="loginBar">
			<div class="loginBarTitle"><span style="color:#00529f;"><?=@$text_login_bar_title?></span><br><?=@$text_login_text?></div>
			<center>
			<form onsubmit="return signIn()" action="signIn.php" method="POST">
				<input type="text" name="username" id="username" class="loginInputs block" placeholder="<?=@$text_username?>" maxlength="16">
				<input type="password" name="password" id="password" class="loginInputs block" placeholder="<?=@$text_password_now?>" maxlength="16">
				<div class="remText">
					<input type="checkbox" id="rm" name="rm" value="remember"> <?=@$TextRemeberMe?>
					
</p>
				</div>
				<p><a href="<?=@$domain?>reset-password.php" style="color:#00529f;font-size:12px;padding: 10px 0px;">Մոռացե՞լ եք գաղտանաբառը</a> </p>
				<?php
				if(!@$_GET['error']){
				?>
				<div id="errorMessage" class="errorMessage"></div>
				<?php
				}
				?>

				<?php
				if(@$_GET['error'] == "true"){
				?>
				<div id="errorMessage" class="errorMessage"><?=@$TextSignInDetilesIsWrong?></div>
				<?php
				}
				?>

				<button class="loginButton" onclick="signIn()"><?=@$text_signin_now?></button>
			</form>
				<button class="regButton" onclick="location.href='<?=$domain?>signup.php'"><?=@$text_signup_now?></button>
			</center>
		</div>

</div>