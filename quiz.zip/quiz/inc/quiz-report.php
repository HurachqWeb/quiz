<?php
@$qr = "SELECT * FROM `quizes_answers` where quiz_id='".@$_GET['id']."' and user_id='".@$profile."'";
@$rs = mysqli_query($db,$qr);
@$rw = mysqli_fetch_array($rs);

@$qr_quiz = "select title_am from quizes where id='".@$_GET['id']."'";
@$rs_quiz = mysqli_query($db,$qr_quiz);
@$rw_quiz = mysqli_fetch_array($rs_quiz);
 @$selector = "
			title_am, 
			right_answer_variant,
			answer_variant_1_am, 
			answer_variant_2_am, 
			answer_variant_3_am, 
			answer_variant_4_am, 
			answer_variant_5_am, 
			answer_variant_6_am, 
			right_answer_variant
			";
@$qr_task_1 = "SELECT ".@$selector." FROM `tasks` where id='".@$rw['task_1']."'";
@$qr_task_2 = "SELECT ".@$selector." FROM `tasks` where id='".@$rw['task_2']."'";
@$qr_task_3 = "SELECT ".@$selector." FROM `tasks` where id='".@$rw['task_3']."'";
@$qr_task_4 = "SELECT ".@$selector." FROM `tasks` where id='".@$rw['task_4']."'";
@$qr_task_5 = "SELECT ".@$selector." FROM `tasks` where id='".@$rw['task_5']."'";
@$qr_task_6 = "SELECT ".@$selector." FROM `tasks` where id='".@$rw['task_6']."'";
@$qr_task_7 = "SELECT ".@$selector." FROM `tasks` where id='".@$rw['task_7']."'";
@$qr_task_8 = "SELECT ".@$selector." FROM `tasks` where id='".@$rw['task_8']."'";
@$qr_task_9 = "SELECT ".@$selector." FROM `tasks` where id='".@$rw['task_9']."'";
@$qr_task_10 = "SELECT ".@$selector." FROM `tasks` where id='".@$rw['task_10']."'";
@$rs_task_1 = mysqli_query(@$db,@$qr_task_1);
@$rs_task_2 = mysqli_query(@$db,@$qr_task_2);
@$rs_task_3 = mysqli_query(@$db,@$qr_task_3);
@$rs_task_4 = mysqli_query(@$db,@$qr_task_4);
@$rs_task_5 = mysqli_query(@$db,@$qr_task_5);
@$rs_task_6 = mysqli_query(@$db,@$qr_task_6);
@$rs_task_7 = mysqli_query(@$db,@$qr_task_7);
@$rs_task_8 = mysqli_query(@$db,@$qr_task_8);
@$rs_task_9 = mysqli_query(@$db,@$qr_task_9);
@$rs_task_10 = mysqli_query(@$db,@$qr_task_10);

@$rw_task_1 = mysqli_fetch_array(@$rs_task_1);
@$rw_task_2 = mysqli_fetch_array(@$rs_task_2);
@$rw_task_3 = mysqli_fetch_array(@$rs_task_3);
@$rw_task_4 = mysqli_fetch_array(@$rs_task_4);
@$rw_task_5 = mysqli_fetch_array(@$rs_task_5);
@$rw_task_6 = mysqli_fetch_array(@$rs_task_6);
@$rw_task_7 = mysqli_fetch_array(@$rs_task_7);
@$rw_task_8 = mysqli_fetch_array(@$rs_task_8);
@$rw_task_9 = mysqli_fetch_array(@$rs_task_9);
@$rw_task_10 = mysqli_fetch_array(@$rs_task_10);

@$ans_1 = "answer_variant_".@$rw['answer_1']."_am";
@$ans_2 = "answer_variant_".@$rw['answer_2']."_am";
@$ans_3 = "answer_variant_".@$rw['answer_3']."_am";
@$ans_4 = "answer_variant_".@$rw['answer_4']."_am";
@$ans_5 = "answer_variant_".@$rw['answer_5']."_am";
@$ans_6 = "answer_variant_".@$rw['answer_6']."_am";
@$ans_7 = "answer_variant_".@$rw['answer_7']."_am";
@$ans_8 = "answer_variant_".@$rw['answer_8']."_am";
@$ans_9 = "answer_variant_".@$rw['answer_9']."_am";
@$ans_10 = "answer_variant_".@$rw['answer_10']."_am";


@$answer_1 = @$rw_task_1[@$ans_1];
@$answer_2 = @$rw_task_2[@$ans_2];
@$answer_3 = @$rw_task_3[@$ans_3];
@$answer_4 = @$rw_task_4[@$ans_4];
@$answer_5 = @$rw_task_5[@$ans_5];
@$answer_6 = @$rw_task_6[@$ans_6];
@$answer_7 = @$rw_task_7[@$ans_7];
@$answer_8 = @$rw_task_8[@$ans_8];
@$answer_9 = @$rw_task_9[@$ans_9];
@$answer_10 = @$rw_task_10[@$ans_10];


if(!$answer_1){
	@$answer_1="Հարցին չեք պատասխանել";
	@$answ_ind_1 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
}else{
	if(@$rw_task_1['right_answer_variant'] == @$rw['answer_1']){
		@$answ_ind_1 = '<i class="fa fa-check" style="font-size:24px;color:green"></i>'; 
	}
	else{
		@$answ_ind_1 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
	}
}
if(!$answer_2){
	@$answer_2="Հարցին չեք պատասխանել";
	@$answ_ind_2 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
}else{
	if(@$rw_task_2['right_answer_variant'] == @$rw['answer_2']){
		@$answ_ind_2 = '<i class="fa fa-check" style="font-size:24px;color:green"></i>'; 
	}
	else{
		@$answ_ind_2 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
	}
}
if(!$answer_3){
	@$answer_3="Հարցին չեք պատասխանել";
	@$answ_ind_3 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
}else{
	if(@$rw_task_3['right_answer_variant'] == @$rw['answer_3']){
		@$answ_ind_3 = '<i class="fa fa-check" style="font-size:24px;color:green"></i>'; 
	}
	else{
		@$answ_ind_3 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
	}
}
if(!$answer_4){
	@$answer_4="Հարցին չեք պատասխանել";
	@$answ_ind_4 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
}else{
	if(@$rw_task_4['right_answer_variant'] == @$rw['answer_4']){
		@$answ_ind_4 = '<i class="fa fa-check" style="font-size:24px;color:green"></i>'; 
	}
	else{
		@$answ_ind_4 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
	}
}
if(!$answer_5){
	@$answer_5="Հարցին չեք պատասխանել";
	@$answ_ind_5 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
}else{
	if(@$rw_task_5['right_answer_variant'] == @$rw['answer_5']){
		@$answ_ind_5 = '<i class="fa fa-check" style="font-size:24px;color:green"></i>'; 
	}
	else{
		@$answ_ind_5 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
	}
}
if(!$answer_6){
	@$answer_6="Հարցին չեք պատասխանել";
	@$answ_ind_6 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
}else{
	if(@$rw_task_6['right_answer_variant'] == @$rw['answer_6']){
		@$answ_ind_6 = '<i class="fa fa-check" style="font-size:24px;color:green"></i>'; 
	}
	else{
		@$answ_ind_6 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
	}
}
if(!$answer_7){
	@$answer_7="Հարցին չեք պատասխանել";
	@$answ_ind_7 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
}else{
	if(@$rw_task_7['right_answer_variant'] == @$rw['answer_7']){
		@$answ_ind_7 = '<i class="fa fa-check" style="font-size:24px;color:green"></i>'; 
	}
	else{
		@$answ_ind_7 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
	}
}
if(!$answer_8){
	@$answer_8="Հարցին չեք պատասխանել";
	@$answ_ind_8 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
}else{
	if(@$rw_task_8['right_answer_variant'] == @$rw['answer_8']){
		@$answ_ind_8 = '<i class="fa fa-check" style="font-size:24px;color:green"></i>'; 
	}
	else{
		@$answ_ind_8 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
	}
}
if(!$answer_9){
	@$answer_9="Հարցին չեք պատասխանել";
	@$answ_ind_9 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
}else{
	if(@$rw_task_9['right_answer_variant'] == @$rw['answer_9']){
		@$answ_ind_9 = '<i class="fa fa-check" style="font-size:24px;color:green"></i>'; 
	}
	else{
		@$answ_ind_9 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
	}
}
if(!$answer_10){
	@$answer_10="Հարցին չեք պատասխանել";
	@$answ_ind_10 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
}else{
	if(@$rw_task_10['right_answer_variant'] == @$rw['answer_10']){
		@$answ_ind_10 = '<i class="fa fa-check" style="font-size:24px;color:green"></i>'; 
	}
	else{
		@$answ_ind_10 = '<i class="fa fa-close" style="font-size:24px;color:red"></i>'; 
	}
}
echo "<div class=\"quiz_answer_h\">1. ".@$rw_task_1['title_am']."</div>";
echo "<div class=\"quiz_answer\">".@$answ_ind_1." ".@$answer_1."</div>";

echo "<div class=\"quiz_answer_h\">2. ".@$rw_task_2['title_am']."</div>";
echo "<div class=\"quiz_answer\">".@$answ_ind_2." ".@$answer_2."</div>";

echo "<div class=\"quiz_answer_h\">3. ".@$rw_task_3['title_am']."</div>";
echo "<div class=\"quiz_answer\">".@$answ_ind_3." ".@$answer_3."</div>";

echo "<div class=\"quiz_answer_h\">4. ".@$rw_task_4['title_am']."</div>";
echo "<div class=\"quiz_answer\">".@$answ_ind_4." ".@$answer_4."</div>";

echo "<div class=\"quiz_answer_h\">5. ".@$rw_task_5['title_am']."</div>";
echo "<div class=\"quiz_answer\">".@$answ_ind_5." ".@$answer_5."</div>";

echo "<div class=\"quiz_answer_h\">6. ".@$rw_task_6['title_am']."</div>";
echo "<div class=\"quiz_answer\">".@$answ_ind_6." ".@$answer_6."</div>";

echo "<div class=\"quiz_answer_h\">7. ".@$rw_task_7['title_am']."</div>";
echo "<div class=\"quiz_answer\">".@$answ_ind_7." ".@$answer_7."</div>";

echo "<div class=\"quiz_answer_h\">8. ".@$rw_task_8['title_am']."</div>";
echo "<div class=\"quiz_answer\">".@$answ_ind_8." ".@$answer_8."</div>";

echo "<div class=\"quiz_answer_h\">9. ".@$rw_task_9['title_am']."</div>";
echo "<div class=\"quiz_answer\">".@$answ_ind_9." ".@$answer_9."</div>";

echo "<div class=\"quiz_answer_h\">10. ".@$rw_task_10['title_am']."</div>";
echo "<div class=\"quiz_answer\">".@$answ_ind_10." ".@$answer_10."</div>";
?>