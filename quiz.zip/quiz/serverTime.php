<?php 
include "config.php";
echo date('H:i:s',$time);
?>