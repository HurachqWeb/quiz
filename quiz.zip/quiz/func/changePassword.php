<?php 
session_start();
include "../config.php";
@$profile = @$_SESSION['user_id'];
if(!@$profile)
{
	@$profile = @$_COOKIE['user_id'];
}
@$qr = "update users set password='".MD5(@$_GET['pass'])."' where id='".@$profile."'";
mysqli_query($db,$qr);
echo @$passwor_change_finished;
?>
