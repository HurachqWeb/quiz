<?php
include "../config.php";
@$var = @$_POST['v'];



@$qr="select id from users where email_address='".@$var."' or phone_number='".@$var."'";
@$rs=mysqli_query($db,$qr); 
@$kl=mysqli_num_rows($rs);
if($kl == 0){
 echo "Ձեր մուտքագրված տվյալով օգտատեր չի գտնվել";
}

?>