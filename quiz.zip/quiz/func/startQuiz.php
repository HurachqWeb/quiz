<?php 
@session_start();
include "../config.php";

@$profile = @$_SESSION['user_id'];
if(!@$profile)
{
	@$profile = @$_COOKIE['user_id'];
}

if(@$profile > 0 && @$_GET['id'] > 0){

	@$qr_check = "select task_1, task_2, task_3, task_4, task_5, task_6, task_7, task_8,task_9, task_10 from quizes_answers where user_id='".@$profile."'";
	@$rs_check = mysqli_query($db,$qr_check);
	@$kl_check = mysqli_num_rows($rs_check);


	@$aditional_query = "";
	for(@$i=1;$i<=$kl_check;$i++){
		@$rw = mysqli_fetch_array($rs_check);
		if(@$i == 1){
			@$aditional_query .= "where id != '".@$rw['task_1']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_2']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_3']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_4']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_5']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_6']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_7']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_8']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_9']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_10']."' and status='active'";
		}else{
			@$aditional_query .= " and id != '".@$rw['task_1']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_2']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_3']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_4']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_5']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_6']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_7']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_8']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_9']."' and status='active'";
			@$aditional_query .= " and id != '".@$rw['task_10']."' and status='active'";
		}
	}
	
	if(!@$aditional_query)
	{
		@$qr_tasks = "SELECT id FROM `tasks` where status='active' order by RAND() limit 10";
	}
	else{
		@$qr_tasks = "SELECT id FROM `tasks` ".@$aditional_query." order by RAND() limit 10";
	}
	echo $qr_tasks;
	@$rs_tasks = mysqli_query($db,$qr_tasks);
	@$kl_tasks = mysqli_num_rows($rs_tasks);

	@$selected_tasks = "";
	for($z=1;$z<=$kl_tasks;$z++){
		@$rw_tasks = mysqli_fetch_array($rs_tasks);
		@$selected_tasks .= "'".@$rw_tasks['id']."'";
		if($z < $kl_tasks){
			@$selected_tasks .= ",";
		}
	}
	@$chek_qr = "select id from quizes_answers where quiz_id='".@$_GET['id']."' and user_id='".@$profile."'";
	@$check_rs = mysqli_query($db, $chek_qr);
	@$check_kl = mysqli_num_rows($check_rs);
	if(@$check_kl == 0)
	{
		@$qr_user = "select birthday from users where id='".@$profile."'";
		@$rs_user = mysqli_query($db,$qr_user);
		@$rw_user = mysqli_fetch_array($rs_user);

		@$data_of_birth = @$rw_user['birthday'];
			@$date_v=@$data_of_birth;
			@$day_v = @$date_v[8].@$date_v[9];
			@$mount_v  = @$date_v[5].@$date_v[6];
			@$year_v = @$date_v[0].@$date_v[1].@$date_v[2].@$date_v[3];

			  $birthDate = @$mount_v."/".@$day_v."/".@$year_v;
			  $birthDate = explode("/", $birthDate);
			  $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
			    ? ((date("Y") - $birthDate[2]) - 1)
			    : (date("Y") - $birthDate[2]));
		
		@$qr_start="insert into quizes_answers (id, quiz_id, user_id, task_1, task_2, task_3,task_4,task_5, task_6, task_7, task_8, task_9, task_10, start_sec, added, last_ansfered_task,points,age,now_sec,visa) VALUES(null,'".@$_GET['id']."','".@$profile."',".@$selected_tasks.",'0','".date('Y-m-d H:i:s', $time)."','0','0','".@$age."','15','".@$_GET['visa']."')";
		@$rs=mysqli_query($db,$qr_start);
		if($rs){
			echo "<META HTTP-EQUIV='Refresh' CONTENT='0; URL=".@$domain."index.php?page=quiz&id=".@$_GET['id']."'>";
		}
		else{echo "error";}
	}
}
?>