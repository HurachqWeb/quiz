<?php 
include "../config.php";

@$qr = "select id from users where phone_number='".@$_GET['u']."'";
@$rs = mysqli_query($db,$qr);
@$kl = mysqli_num_rows($rs);
@$aa = @$_GET['u'];
@$input_code = $aa[0].$aa[1];
@$codes=array(91, 99, 96, 43, 33, 97, 55, 95, 41, 44, 66, 50, 93, 94, 77, 98);
if(in_array($input_code, $codes)){
	
}
else {
	echo "Սխալ Հեռախոսահամար․ Խնդրում ենք մուտքագրել ճիշգրիտ հեռախոսահամարի կոդ, առանց դիմացի 0-ի<p>";
}
if($kl > 0){
	echo @$text_exist_this_phone_number;
}
?>