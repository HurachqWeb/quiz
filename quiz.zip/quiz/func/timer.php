<?php 
@session_start();
  $DB_HOST="localhost";
  $DB_USER="quiz";
  $DB_PASS='Arhr.!1985';
  $DB_NAME="quiz";
  @$db=mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
@$profile = @$_SESSION['user_id'];
if(!@$profile)
{
	@$profile = @$_COOKIE['user_id'];
}

 function timerStop2($secondCount){
  @$minute = floor($secondCount/60);
  if(@$minute < 10)
  {
    @$minute_echo = "0".@$minute;
  }else{
    @$minute_echo = @$minute;
  } 
   
  @$second = $secondCount-(@$minute*60);
  if(@$second <= 0)
  {
    @$second_echo = "00";
  }
  else{
    if(@$second < 10){
      @$second_echo = "0".@$second;
    }else{
      @$second_echo = @$second;
    }
  }
  return $minute_echo.":".$second_echo;
}

	@$qr_check = "select start_sec, last_ansfered_task from quizes_answers where user_id='".@$profile."' and quiz_id='".@$_GET['id']."'";
	@$rs_check = mysqli_query($db,$qr_check);
	@$rw_check = mysqli_fetch_array($rs_check);
	if($rw_check['last_ansfered_task'] < 10)
	{
		
			@$new_start_sec = $rw_check['start_sec']+1;
	
		if(@$new_start_sec  >= 150){
			@$new_start_sec=150;
		}
	
		@$now_sec = @$_GET['secanswer'];
		if(@$now_sec == "01")
		{
			@$now_sec = 15;
		}
		@$qr="update quizes_answers set start_sec='".@$new_start_sec."',now_sec='".$now_sec."' where user_id='".@$profile."' and quiz_id='".@$_GET['id']."'";
		mysqli_query($db,$qr);
		@$stat=@$new_start_sec;

	echo timerStop2($stat);
	}
	else {
		@$aaaaa = $rw_check['start_sec']-1;
		echo timerStop2(@$aaaaa);
	}

	


?>