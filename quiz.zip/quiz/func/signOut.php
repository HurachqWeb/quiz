<?php 
session_start();
include "../config.php";

	@$_SESSION['user_id']='0';
	setcookie("user_id", "0", time()-60*60*24*15, "/");
	echo "<META HTTP-EQUIV='Refresh' CONTENT='0; URL=".@$domain."'>";
?>
