<?php 
@session_start();
include "../config.php";






@$name = @$_GET['name'];
@$lastname = @$_GET['lastname'];
@$username = @$_GET['username'];
@$password = @$_GET['password'];
@$birthDay = @$_GET['birthDay'];
@$phoneNumber = @$_GET['phoneNumber'];


echo "<input type='hidden' id='s2_name' value='".@$name."'>";
echo "<input type='hidden' id='s2_lastname' value='".@$lastname."'>";
echo "<input type='hidden' id='s2_username' value='".@$username."'>";
echo "<input type='hidden' id='s2_password' value='".@$password."'>";
echo "<input type='hidden' id='s2_birthDay' value='".@$birthDay."'>";
echo "<input type='hidden' id='s2_phoneNumber' value='".@$phoneNumber."'>";

?>
<center>
	<div class="loginBarTitle"><?=@$text_signup_now?></div>
		
	<p><?=@$TextAcceptRegSms?></p>
	<p>
		<iframe id="siteRuls" src="<?=@$doamin?>/inc/site-rules.php" style="border:none;"></iframe>
		<p>
		<input type="checkbox" id="rule1" name="rule" onchange="chekIng()" value="acceptRule" disabled> <?=@$IAcceptedRuleText?>
			<p>
		<input type="checkbox" id="rule2" name="rule" onchange="chekIng()" value="acceptRule" disabled> <?php
					@$data_of_birth =@$birthDay;
			@$date_v=@$data_of_birth;
			@$day_v = @$date_v[8].@$date_v[9];
			@$mount_v  = @$date_v[5].@$date_v[6];
			@$year_v = @$date_v[0].@$date_v[1].@$date_v[2].@$date_v[3];

			  $birthDate = @$mount_v."/".@$day_v."/".@$year_v;
			  $birthDate = explode("/", $birthDate);
			  $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
			    ? ((date("Y") - $birthDate[2]) - 1)
			    : (date("Y") - $birthDate[2]));

			  if(@$age < 21){
			  	echo @$IAcceptedRuleText3;
			  }else{
			  	echo @$IAcceptedRuleText2;
			  }

	?><p>
	<input type="text" name="actIvateSMS" id="actIvateSMS" class="loginInputs" placeholder="<?=@$textsixcode?>" pattern="[0-9]*" inputmode="numeric" maxlength="4" disabled required />

	<p>
		     <div id="errorMessageStep2" class="errorMessage"></div>
			<button class="regButton" onclick="regActivation()"><?=@$textAccept?></button>
</center>
<?php
$url="https://api.dexatel.com/v1/templates";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HTTPHEADER,  array(
			  "Content-Type: application/json",
      	"X-Dexatel-Key: edc8fc545016a4fa210dbecf2d5e07ca"    
   ));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
	//curl_setopt($ch, CURLOPT_POSTFIELDS, array('name: verification','text: Hi, your verification code is {code}','channel: SMS'));
	$result = curl_exec($ch);

	@$id = strstr($result,'"id":"');
	@$id = strstr($id,'","account_id"',true);
	@$id = str_ireplace('"id":"','',$id);

	@$phone='374'.@$_GET['phoneNumber'];
	@$data = array('data' => array('sender'=>'Madridista','phone'=>$phone,'template' => $id,'code_length'=> '4'));
	$data_string = json_encode($data);

	@$url1='https://api.dexatel.com/v1/verifications';
	$ch1 = curl_init();
    curl_setopt($ch1, CURLOPT_URL, $url1);
	curl_setopt($ch1, CURLOPT_HTTPHEADER,  array(
			  "Content-Type: application/json",
			  "filter: countries",
      	"X-Dexatel-Key: edc8fc545016a4fa210dbecf2d5e07ca"    
   ));
	curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, true);
	curl_setopt($ch1, CURLOPT_POSTFIELDS, $data_string);
	$result1 = curl_exec($ch1);

    @$activatioCode = strstr($result1,'"code":"');
    @$activatioCode = strstr($activatioCode,'","create_date',true);
    @$activatioCode = str_ireplace('"code":"','',@$activatioCode);
echo "<input type='hidden' id='s2_activatioCode' value='".@$activatioCode."'>";
?>