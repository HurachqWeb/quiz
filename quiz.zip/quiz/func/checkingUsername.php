<?php 
include "../config.php";

@$qr = "select id from users where username='".@$_GET['u']."'";
@$rs = mysqli_query($db,$qr);
@$kl = mysqli_num_rows($rs);

if($kl > 0){
	echo @$text_exist_this_userneme;
}
?>