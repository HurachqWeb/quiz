<?php 
session_start();
include "../config.php";
@$profile = @$_SESSION['user_id'];
if(!@$profile)
{
	@$profile = @$_COOKIE['user_id'];
}
@$qr = "select password from users where id='".@$profile."'";
@$rs = mysqli_query($db,$qr);
@$rw = mysqli_fetch_array($rs);
if(@$rw['password'] != MD5(@$_GET['pass']))
{
	echo @$password_wrong;
}
?>
