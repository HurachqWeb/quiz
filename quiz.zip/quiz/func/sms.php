<?php
require_once 'HTTP/Request2.php';
$request = new HTTP_Request2();
$request->setUrl('https://api.dexatel.com/v1/messages');
$request->setMethod(HTTP_Request2::METHOD_POST);
$request->setConfig(array(
'follow_redirects' => TRUE
 ));

$request->setHeader(array(
'Content-Type' => 'application/json',
'X-Dexatel-Key' => '0940dXXXXXXXXXXXXXXXXXX'
  ));

$request->setBody('{\n"data": {\n"from": "Dexatel2",\n"to": [\n"18558675310"\n],\n"text": "This is my test message",\n"channel": "sms"\n}\n}');

try {
$response = $request->send();
if ($response->getStatus() == 200) {
echo $response->getBody();
 }
else {
echo 'Unexpected HTTP status: ' . $response->getStatus() . ' ' .
$response->getReasonPhrase();
}

}

catch(HTTP_Request2_Exception $e) {
echo 'Error: ' . $e->getMessage();
}
//This is an example of a Json response:
{
 "data": [{
"id": "e4a2bcXXXXXXXXXXXXXXXXXXXXXX",
"account_id": "78427XXXXXXXXXXXXXXXXXXXXXXX",
"text": "This is my test message",
"from": "Dexatel2",
"to": "18558675310",
"channel": "SMS",
"status": "enroute",
"create_date": "".date('Y-m-d H:i:s')."",
"update_date": "2023-06-12 12:00:42",
"encoding": "GSM-7",
"segment_count": 1
 }]
 }
?>
