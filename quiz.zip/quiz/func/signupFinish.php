<?php 
session_start();
include "../config.php";
//@$activatioCode = rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9);
@$activatioCode = @$_GET['activatonCode'];
@$name = @$_GET['name'];
@$lastname = @$_GET['lastname'];
@$username = @$_GET['username'];
@$password = @$_GET['password'];
@$birthDay = @$_GET['birthDay'];
@$phoneNumber = @$_GET['phoneNumber'];

@$qr="insert into users (id,reg_date,name,last_name,username,birthday,password,phone_number,activation_code) values(null,'".date('Y-m-d H:i:s',$time)."','".@$name."','".@$lastname."','".@$username."','".@$birthDay."','".MD5(@$password)."','".@$phoneNumber."','".@$activatioCode."')";
mysqli_query($db,$qr);

@$qr_signin = "select id from users where username='".@$username."' and password='".MD5(@$password)."'";
@$rs_signin = mysqli_query($db,$qr_signin);
@$rw_signin = mysqli_fetch_array($rs_signin);
if(@$rw_signin['id'] > 0)
{
	@$_SESSION['user_id']=@$rw_signin['id'];
}
?>
<center>
		<p><?=@$thankYouForRegistration?></p>
		<button class="loginButton" onclick="location.href='index.php?page=profile'"><?=@$text_login_text?></button>
</center>
