 <meta charset="UTF-8">
 <?php
include "config.php";
$file = "users_date_".date('Y-m-d')."_".time().".csv";
 //header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
 //header('Content-Disposition: attachment; filename='.$file);
 $content = "ID, REG. DATE, NAME, LAST NAME, USERNAME, BIRTHDAY, AGE, PHONE, EMAIL\n";
 @$age_array = array('over_21'=>"now_age >= '21'",'under_21'=>"now_age < '21'",'all'=>"now_age >='0'");
 @$additional_date_by_query = "";

 if(@$_GET['from'] && @$_GET['to'])
 {
 	 if(@$_GET['age'] != "all")
	 {
	 	@$additional_date_by_query .= " and ";
	 }
 	@$additional_date_by_query .= " reg_date >= '".@$_GET['from']."' and reg_date <= '".@$_GET['to']."'";
 }
 else {
 	if(@$_GET['from'])
 	{
 		if(@$_GET['age'] != "all")
		 {
		 	@$additional_date_by_query .= " and ";
		 }
 		@$additional_date_by_query .= " reg_date = '".@$_GET['from']."'";
 	}
 }

 @$qr = "select * from users where ".@$age_array[@$_GET['age']]." ".@$additional_date_by_query." order by id asc";
 @$rs = mysqli_query($db,$qr);
 while(@$rw = mysqli_fetch_array($rs)){
 	$content .= @$rw['id'].",".@$rw['reg_date'].",".@$rw['name'].",".@$rw['last_name'].",".@$rw['username'].",".@$rw['birthday'].",".@$rw['now_age'].",".@$rw['phone_number'].",".@$rw['email_address']."\n";
 }
 @$contUTF8  = utf8_encode($content);
mb_internal_encoding('UTF-8');
header('Content-type: text/html; charset=UTF-8');
$d1 = fopen($file, "w");
fwrite($d1, @$content);
fclose($d1);

@$fileSize=filesize($file);
header ("Content-type: octet/stream");
header("Content-Transfer-Encoding: Binary");
header ("Content-disposition: attachment; filename=".$file);
header("Content-Length: " . $fileSize);
readfile($file);
unlink($file);
?>