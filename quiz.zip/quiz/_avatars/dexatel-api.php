<?php 

$params=array("sender"=>"REALMADRID.am","phone"=>"37433839833","template"=>"083ce267-21ba-481a-9919-68ac75bbf458","code_length"=>"6");
@$apiKey="edc8fc545016a4fa210dbecf2d5e07ca";
$headers = array('X-Dexatel-Key' => @$apiKey,'Content-Type' => 'application/json');
$url="https://api.dexatel.com/v1/verifications";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER,  array(
      'X-Dexatel-Key: edc8fc545016a4fa210dbecf2d5e07assdasca',
      'Content-Type: application/json'
   ));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
	$result = curl_exec($ch);

	echo "Result: ".$result;
	$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);
	@$res=json_decode($result, true);

	echo $httpcode; 
?>